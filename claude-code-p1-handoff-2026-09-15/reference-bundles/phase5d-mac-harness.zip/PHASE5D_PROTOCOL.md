# Phase 5D — Budget-Bounded Runtime Kernel Selector

Status: PROTOCOL FROZEN BEFORE CANONICAL MEASUREMENT
Date: 2026-09-15

## Research question

Can a deadline-aware browser runtime selector preserve low canonical
kernel regret while keeping tuning latency below 200 ms?

## Frozen WASM

SHA256:

944fc9f7818d34383a012328525243b069bf77fd147aa4ce22a08f657b720561

G / D / P kernels are unchanged from frozen Phase 4D.

## Candidates

generic
dot
pairwise

## Tuning shape

n = 6912

## Prewarm

Each candidate:

target = 3 ms
internal rounds = 1
discarded

Prewarm is included in selector wall time.

## Stage 1

Balanced orders:

generic dot pairwise
dot pairwise generic
pairwise generic dot

Per measurement:

target = 4 ms
internal rounds = 1

Score:

median ms/call

## Confidence threshold

5%

margin:

second_best / best - 1

If Stage-1 margin >= 5%:

select Stage-1 best immediately.

## Near-tie policy

If Stage-1 margin < 5%:

Check selector elapsed time.

Soft confirmation deadline:

140 ms

If elapsed time is below 140 ms:

run exactly one confirmation pair using the Stage-1 top two candidates.

The confirmation pair contains one additional measurement per candidate.

Once a confirmation pair starts, both measurements are completed.

No further confirmation is allowed.

If elapsed time is already >= 140 ms:

skip confirmation and select the Stage-1 measured best.

## Final selection

When confirmation runs:

combine Stage-1 and confirmation samples.

Recompute medians.

Select final measured best.

There is no browser identity rule and no fixed kernel fallback.

## Latency gate

selector_wall_ms < 200 ms

The 140 ms soft confirmation deadline provides headroom for one
confirmation pair but does not claim a hard real-time guarantee.

Actual selector wall time remains the measured gate.

## External performance oracle

No short live benchmark is used to validate selection.

Selection quality is evaluated against the independently frozen
Phase 4D canonical cross-platform results.

Windows Chrome 152:

D/G = 1.9334423589821974
P/G = 1.6320174839256016

M1 Chrome 153:

D/G = 0.8235469730014051
P/G = 1.124668707960832

M1 Firefox 155:

D/G = 1.296438101151774
P/G = 1.5132518206746761

M1 Safari 17.4.1:

D/G = 0.8681270666685896
P/G = 1.0126606789094013

## Canonical regret gate

canonical_regret <= 1.02x

## Reproducibility

Two independent runs per environment:

Windows Chrome 152
M1 Chrome 153
M1 Firefox 155
M1 Safari 17.4.1

Every canonical run must satisfy both:

selector_wall_ms < 200 ms
canonical_regret <= 1.02x

## Frozen after measurement begins

The following must not change after the first canonical run:

- 5% confidence threshold
- 140 ms soft confirmation deadline
- tuning shape
- Stage-1 orders
- measurement targets
- one-pair confirmation limit
- selection rule
- 200 ms wall gate
- 1.02x canonical regret gate
- Phase 4D oracle

Any change requires a new phase/version.
