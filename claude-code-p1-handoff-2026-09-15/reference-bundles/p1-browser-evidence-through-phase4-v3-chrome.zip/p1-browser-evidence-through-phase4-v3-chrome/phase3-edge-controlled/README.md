# Phase 3 — Controlled Browser Benchmark Evidence

Browser: Microsoft Edge 152 / Chromium 152 on Windows 11  
Threads: 1  
Model: `ggml-model-i2_s.gguf` (1844472032 bytes)  
Protocol: ABBA (`generic -> handwritten -> handwritten -> generic`)  
Each position: fresh Worker, 1 warmup, 3 measured repetitions.  
Model load excluded. No outlier removal.

## Results

| Workload | Generic median | Handwritten median | Speedup |
|---|---:|---:|---:|
| Prefill 32 | 12,484.60 ms | 6,268.00 ms | 1.9918x |
| Prefill 64 | 25,090.75 ms | 13,539.85 ms | 1.8531x |
| Prefill 128 | 47,072.15 ms | 25,280.90 ms | 1.8620x |
| Prefill 256 | 97,438.75 ms | 54,108.80 ms | 1.8008x |
| Decode 64 | 41,983.45 ms | 31,279.20 ms | 1.3422x |

Prefill geometric-mean speedup: **1.8756x**  
All-workload geometric-mean speedup: **1.7542x**

Note: Prefill-32 is 1.9918x, so it should not be described as exceeding 2x.
