```
================================
ABBA prefill-32
model: ggml-model-i2_s.gguf
bytes: 1844472032
order: generic -> handwritten -> handwritten -> generic

--- run 1/4: generic ---
[1/4] generic model load: 22613.1 ms
[1/4] generic warmup done
[1/4] generic rep 0: 12571.3 ms (2.545 t/s)
[1/4] generic rep 1: 12397.9 ms (2.581 t/s)
[1/4] generic rep 2: 17664.9 ms (1.812 t/s)

--- run 2/4: handwritten ---
[2/4] handwritten model load: 27496.1 ms
[2/4] handwritten warmup done
[2/4] handwritten rep 0: 6300.1 ms (5.079 t/s)
[2/4] handwritten rep 1: 6239.3 ms (5.129 t/s)
[2/4] handwritten rep 2: 6173.8 ms (5.183 t/s)

--- run 3/4: handwritten ---
[3/4] handwritten model load: 13809.6 ms
[3/4] handwritten warmup done
[3/4] handwritten rep 0: 6089.0 ms (5.255 t/s)
[3/4] handwritten rep 1: 6296.7 ms (5.082 t/s)
[3/4] handwritten rep 2: 6451.8 ms (4.960 t/s)

--- run 4/4: generic ---
[4/4] generic model load: 13029.6 ms
[4/4] generic warmup done
[4/4] generic rep 0: 11514.5 ms (2.779 t/s)
[4/4] generic rep 1: 12162.6 ms (2.631 t/s)
[4/4] generic rep 2: 13397.3 ms (2.389 t/s)

=== FINAL ===
generic median: 12484.60 ms
handwritten median: 6268.00 ms
speedup: 1.992x

{
  "schema": "p1-browser-abba-v1",
  "timestamp": "2026-09-13T17:08:00.467Z",
  "browser": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0",
  "hardware_concurrency": 8,
  "device_memory_gb": 32,
  "cross_origin_isolated": false,
  "model": {
    "name": "ggml-model-i2_s.gguf",
    "bytes": 1844472032
  },
  "workload": {
    "kind": "prefill",
    "n_tokens": 32,
    "threads": 1,
    "warmups_per_worker": 1,
    "measurements_per_worker": 3,
    "order": [
      "generic",
      "handwritten",
      "handwritten",
      "generic"
    ]
  },
  "generic": {
    "variant": "generic",
    "sample_count": 6,
    "pooled_median_ms": 12484.599999999999,
    "pooled_median_tokens_per_second": 2.56328142942,
    "mean_ms": 13284.75,
    "stddev_ms": 2231.004304567789,
    "cv": 0.16793724417605066,
    "run_medians_ms": [
      12571.3,
      12162.6
    ],
    "samples_ms": [
      12571.3,
      12397.9,
      17664.9,
      11514.5,
      12162.6,
      13397.3
    ]
  },
  "handwritten": {
    "variant": "handwritten",
    "sample_count": 6,
    "pooled_median_ms": 6268,
    "pooled_median_tokens_per_second": 5.105403782865,
    "mean_ms": 6258.450000000001,
    "stddev_ms": 123.9577791024025,
    "cv": 0.019806466313927965,
    "run_medians_ms": [
      6239.3,
      6296.7
    ],
    "samples_ms": [
      6300.1,
      6239.3,
      6173.8,
      6089,
      6296.7,
      6451.8
    ]
  },
  "speedup": 1.991799617102744,
  "suite_wall_ms": 240283.30000001192,
  "notes": [
    "Fresh Web Worker for every ABBA position.",
    "Model load excluded from workload timing.",
    "No measurement samples removed as outliers.",
    "Pooled median uses all six samples per implementation."
  ]
}

================================
ABBA prefill-64
model: ggml-model-i2_s.gguf
bytes: 1844472032
order: generic -> handwritten -> handwritten -> generic

--- run 1/4: generic ---
[1/4] generic model load: 11996.5 ms
[1/4] generic warmup done
[1/4] generic rep 0: 23911.2 ms (2.677 t/s)
[1/4] generic rep 1: 24049.4 ms (2.661 t/s)
[1/4] generic rep 2: 25374.6 ms (2.522 t/s)

--- run 2/4: handwritten ---
[2/4] handwritten model load: 14495.7 ms
[2/4] handwritten warmup done
[2/4] handwritten rep 0: 12889.4 ms (4.965 t/s)
[2/4] handwritten rep 1: 12780.5 ms (5.008 t/s)
[2/4] handwritten rep 2: 13477.7 ms (4.749 t/s)

--- run 3/4: handwritten ---
[3/4] handwritten model load: 17191.6 ms
[3/4] handwritten warmup done
[3/4] handwritten rep 0: 13602.0 ms (4.705 t/s)
[3/4] handwritten rep 1: 16954.0 ms (3.775 t/s)
[3/4] handwritten rep 2: 15106.0 ms (4.237 t/s)

--- run 4/4: generic ---
[4/4] generic model load: 14643.9 ms
[4/4] generic warmup done
[4/4] generic rep 0: 26932.3 ms (2.376 t/s)
[4/4] generic rep 1: 29726.3 ms (2.153 t/s)
[4/4] generic rep 2: 24806.9 ms (2.580 t/s)

=== FINAL ===
generic median: 25090.75 ms
handwritten median: 13539.85 ms
speedup: 1.853x

{
  "schema": "p1-browser-abba-v1",
  "timestamp": "2026-09-13T17:15:15.341Z",
  "browser": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0",
  "hardware_concurrency": 8,
  "device_memory_gb": 32,
  "cross_origin_isolated": false,
  "model": {
    "name": "ggml-model-i2_s.gguf",
    "bytes": 1844472032
  },
  "workload": {
    "kind": "prefill",
    "n_tokens": 64,
    "threads": 1,
    "warmups_per_worker": 1,
    "measurements_per_worker": 3,
    "order": [
      "generic",
      "handwritten",
      "handwritten",
      "generic"
    ]
  },
  "generic": {
    "variant": "generic",
    "sample_count": 6,
    "pooled_median_ms": 25090.75,
    "pooled_median_tokens_per_second": 2.55106730277,
    "mean_ms": 25800.11666666667,
    "stddev_ms": 2213.4729936610165,
    "cv": 0.08579313893261528,
    "run_medians_ms": [
      24049.4,
      26932.3
    ],
    "samples_ms": [
      23911.2,
      24049.4,
      25374.6,
      26932.3,
      29726.3,
      24806.9
    ]
  },
  "handwritten": {
    "variant": "handwritten",
    "sample_count": 6,
    "pooled_median_ms": 13539.85,
    "pooled_median_tokens_per_second": 4.72688755617,
    "mean_ms": 14134.933333333334,
    "stddev_ms": 1611.9506117330848,
    "cv": 0.11404019910951718,
    "run_medians_ms": [
      12889.4,
      15106
    ],
    "samples_ms": [
      12889.4,
      12780.5,
      13477.7,
      13602,
      16954,
      15106
    ]
  },
  "speedup": 1.8531039856423814,
  "suite_wall_ms": 401484.8000000119,
  "notes": [
    "Fresh Web Worker for every ABBA position.",
    "Model load excluded from workload timing.",
    "No measurement samples removed as outliers.",
    "Pooled median uses all six samples per implementation."
  ]
}

================================
ABBA prefill-128
model: ggml-model-i2_s.gguf
bytes: 1844472032
order: generic -> handwritten -> handwritten -> generic

--- run 1/4: generic ---
[1/4] generic model load: 20559.2 ms
[1/4] generic warmup done
[1/4] generic rep 0: 47534.1 ms (2.693 t/s)
[1/4] generic rep 1: 48408.0 ms (2.644 t/s)
[1/4] generic rep 2: 49602.7 ms (2.581 t/s)

--- run 2/4: handwritten ---
[2/4] handwritten model load: 13706.5 ms
[2/4] handwritten warmup done
[2/4] handwritten rep 0: 25453.5 ms (5.029 t/s)
[2/4] handwritten rep 1: 26029.9 ms (4.917 t/s)
[2/4] handwritten rep 2: 24895.5 ms (5.141 t/s)

--- run 3/4: handwritten ---
[3/4] handwritten model load: 13803.6 ms
[3/4] handwritten warmup done
[3/4] handwritten rep 0: 25108.3 ms (5.098 t/s)
[3/4] handwritten rep 1: 25575.0 ms (5.005 t/s)
[3/4] handwritten rep 2: 25084.8 ms (5.103 t/s)

--- run 4/4: generic ---
[4/4] generic model load: 14973.0 ms
[4/4] generic warmup done
[4/4] generic rep 0: 46127.1 ms (2.775 t/s)
[4/4] generic rep 1: 46610.2 ms (2.746 t/s)
[4/4] generic rep 2: 45549.5 ms (2.810 t/s)

=== FINAL ===
generic median: 47072.15 ms
handwritten median: 25280.90 ms
speedup: 1.862x

{
  "schema": "p1-browser-abba-v1",
  "timestamp": "2026-09-13T17:26:53.806Z",
  "browser": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0",
  "hardware_concurrency": 8,
  "device_memory_gb": 32,
  "cross_origin_isolated": false,
  "model": {
    "name": "ggml-model-i2_s.gguf",
    "bytes": 1844472032
  },
  "workload": {
    "kind": "prefill",
    "n_tokens": 128,
    "threads": 1,
    "warmups_per_worker": 1,
    "measurements_per_worker": 3,
    "order": [
      "generic",
      "handwritten",
      "handwritten",
      "generic"
    ]
  },
  "generic": {
    "variant": "generic",
    "sample_count": 6,
    "pooled_median_ms": 47072.149999999994,
    "pooled_median_tokens_per_second": 2.719491856595,
    "mean_ms": 47305.26666666666,
    "stddev_ms": 1516.6078183454895,
    "cv": 0.03206002048423409,
    "run_medians_ms": [
      48408,
      46127.1
    ],
    "samples_ms": [
      47534.1,
      48408,
      49602.7,
      46127.1,
      46610.2,
      45549.5
    ]
  },
  "handwritten": {
    "variant": "handwritten",
    "sample_count": 6,
    "pooled_median_ms": 25280.9,
    "pooled_median_tokens_per_second": 5.06334689815,
    "mean_ms": 25357.833333333332,
    "stddev_ms": 414.37984346088456,
    "cv": 0.016341295331260608,
    "run_medians_ms": [
      25453.5,
      25108.3
    ],
    "samples_ms": [
      25453.5,
      26029.9,
      24895.5,
      25108.3,
      25575,
      25084.8
    ]
  },
  "speedup": 1.861964961690446,
  "suite_wall_ms": 667433.8999999762,
  "notes": [
    "Fresh Web Worker for every ABBA position.",
    "Model load excluded from workload timing.",
    "No measurement samples removed as outliers.",
    "Pooled median uses all six samples per implementation."
  ]
}

================================
ABBA prefill-256
model: ggml-model-i2_s.gguf
bytes: 1844472032
order: generic -> handwritten -> handwritten -> generic

--- run 1/4: generic ---
[1/4] generic model load: 10945.4 ms
[1/4] generic warmup done
[1/4] generic rep 0: 95274.0 ms (2.687 t/s)
[1/4] generic rep 1: 100131.3 ms (2.557 t/s)
[1/4] generic rep 2: 106603.6 ms (2.401 t/s)

--- run 2/4: handwritten ---
[2/4] handwritten model load: 13657.5 ms
[2/4] handwritten warmup done
[2/4] handwritten rep 0: 54803.9 ms (4.671 t/s)
[2/4] handwritten rep 1: 53788.8 ms (4.759 t/s)
[2/4] handwritten rep 2: 55428.7 ms (4.619 t/s)

--- run 3/4: handwritten ---
[3/4] handwritten model load: 12152.4 ms
[3/4] handwritten warmup done
[3/4] handwritten rep 0: 53741.5 ms (4.764 t/s)
[3/4] handwritten rep 1: 54428.8 ms (4.703 t/s)
[3/4] handwritten rep 2: 53726.4 ms (4.765 t/s)

--- run 4/4: generic ---
[4/4] generic model load: 14771.4 ms
[4/4] generic warmup done
[4/4] generic rep 0: 95678.5 ms (2.676 t/s)
[4/4] generic rep 1: 97513.4 ms (2.625 t/s)
[4/4] generic rep 2: 97364.1 ms (2.629 t/s)

=== FINAL ===
generic median: 97438.75 ms
handwritten median: 54108.80 ms
speedup: 1.801x

{
  "schema": "p1-browser-abba-v1",
  "timestamp": "2026-09-13T17:48:40.168Z",
  "browser": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0",
  "hardware_concurrency": 8,
  "device_memory_gb": 32,
  "cross_origin_isolated": false,
  "model": {
    "name": "ggml-model-i2_s.gguf",
    "bytes": 1844472032
  },
  "workload": {
    "kind": "prefill",
    "n_tokens": 256,
    "threads": 1,
    "warmups_per_worker": 1,
    "measurements_per_worker": 3,
    "order": [
      "generic",
      "handwritten",
      "handwritten",
      "generic"
    ]
  },
  "generic": {
    "variant": "generic",
    "sample_count": 6,
    "pooled_median_ms": 97438.75,
    "pooled_median_tokens_per_second": 2.62729304571,
    "mean_ms": 98760.81666666667,
    "stddev_ms": 4208.394165672542,
    "cv": 0.04261198223862948,
    "run_medians_ms": [
      100131.3,
      97364.1
    ],
    "samples_ms": [
      95274,
      100131.3,
      106603.6,
      95678.5,
      97513.4,
      97364.1
    ]
  },
  "handwritten": {
    "variant": "handwritten",
    "sample_count": 6,
    "pooled_median_ms": 54108.8,
    "pooled_median_tokens_per_second": 4.7313737145450006,
    "mean_ms": 54319.68333333334,
    "stddev_ms": 699.2007420381252,
    "cv": 0.012871959097174262,
    "run_medians_ms": [
      54803.9,
      53741.5
    ],
    "samples_ms": [
      54803.9,
      53788.8,
      55428.7,
      53741.5,
      54428.8,
      53726.4
    ]
  },
  "speedup": 1.8007930318173753,
  "suite_wall_ms": 1282956.7000000477,
  "notes": [
    "Fresh Web Worker for every ABBA position.",
    "Model load excluded from workload timing.",
    "No measurement samples removed as outliers.",
    "Pooled median uses all six samples per implementation."
  ]
}

================================
ABBA decode-64
model: ggml-model-i2_s.gguf
bytes: 1844472032
order: generic -> handwritten -> handwritten -> generic

--- run 1/4: generic ---
[1/4] generic model load: 9849.0 ms
[1/4] generic warmup done
[1/4] generic rep 0: 42287.9 ms (1.513 t/s)
[1/4] generic rep 1: 41070.3 ms (1.558 t/s)
[1/4] generic rep 2: 41679.0 ms (1.536 t/s)

--- run 2/4: handwritten ---
[2/4] handwritten model load: 13256.4 ms
[2/4] handwritten warmup done
[2/4] handwritten rep 0: 31658.8 ms (2.022 t/s)
[2/4] handwritten rep 1: 30680.2 ms (2.086 t/s)
[2/4] handwritten rep 2: 31586.1 ms (2.026 t/s)

--- run 3/4: handwritten ---
[3/4] handwritten model load: 13317.5 ms
[3/4] handwritten warmup done
[3/4] handwritten rep 0: 31587.2 ms (2.026 t/s)
[3/4] handwritten rep 1: 30710.7 ms (2.084 t/s)
[3/4] handwritten rep 2: 30972.3 ms (2.066 t/s)

--- run 4/4: generic ---
[4/4] generic model load: 12944.4 ms
[4/4] generic warmup done
[4/4] generic rep 0: 43428.4 ms (1.474 t/s)
[4/4] generic rep 1: 43793.7 ms (1.461 t/s)
[4/4] generic rep 2: 41183.6 ms (1.554 t/s)

=== FINAL ===
generic median: 41983.45 ms
handwritten median: 31279.20 ms
speedup: 1.342x

{
  "schema": "p1-browser-abba-v1",
  "timestamp": "2026-09-13T18:00:43.724Z",
  "browser": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0",
  "hardware_concurrency": 8,
  "device_memory_gb": 32,
  "cross_origin_isolated": false,
  "model": {
    "name": "ggml-model-i2_s.gguf",
    "bytes": 1844472032
  },
  "workload": {
    "kind": "decode",
    "n_tokens": 64,
    "threads": 1,
    "warmups_per_worker": 1,
    "measurements_per_worker": 3,
    "order": [
      "generic",
      "handwritten",
      "handwritten",
      "generic"
    ]
  },
  "generic": {
    "variant": "generic",
    "sample_count": 6,
    "pooled_median_ms": 41983.45,
    "pooled_median_tokens_per_second": 1.524490381905,
    "mean_ms": 42240.48333333333,
    "stddev_ms": 1151.3011168528697,
    "cv": 0.02725586986700838,
    "run_medians_ms": [
      41679,
      43428.4
    ],
    "samples_ms": [
      42287.9,
      41070.3,
      41679,
      43428.4,
      43793.7,
      41183.6
    ]
  },
  "handwritten": {
    "variant": "handwritten",
    "sample_count": 6,
    "pooled_median_ms": 31279.199999999997,
    "pooled_median_tokens_per_second": 2.046285127275,
    "mean_ms": 31199.216666666664,
    "stddev_ms": 462.8054944214321,
    "cv": 0.014833881868447514,
    "run_medians_ms": [
      31586.1,
      30972.3
    ],
    "samples_ms": [
      31658.8,
      30680.2,
      31586.1,
      31587.2,
      30710.7,
      30972.3
    ]
  },
  "speedup": 1.342216233151743,
  "suite_wall_ms": 675748.3000000119,
  "notes": [
    "Fresh Web Worker for every ABBA position.",
    "Model load excluded from workload timing.",
    "No measurement samples removed as outliers.",
    "Pooled median uses all six samples per implementation."
  ]
}
```