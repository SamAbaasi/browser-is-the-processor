```
=== PRIMING — NOT MEASURED ===
[prime 1/4] generic n=2560 0.000447464 ms
[prime 1/4] generic n=3200 0.000593758 ms
[prime 1/4] generic n=6912 0.001210022 ms
[prime 1/4] generic n=8192 0.001395035 ms
[prime 2/4] handwritten n=2560 0.000219917 ms
[prime 2/4] handwritten n=3200 0.000277328 ms
[prime 2/4] handwritten n=6912 0.000603104 ms
[prime 2/4] handwritten n=8192 0.000703621 ms
[prime 3/4] generic n=2560 0.000434780 ms
[prime 3/4] generic n=3200 0.000570679 ms
[prime 3/4] generic n=6912 0.001166153 ms
[prime 3/4] generic n=8192 0.001402283 ms
[prime 4/4] handwritten n=2560 0.000221300 ms
[prime 4/4] handwritten n=3200 0.000286770 ms
[prime 4/4] handwritten n=6912 0.000584030 ms
[prime 4/4] handwritten n=8192 0.000692177 ms

=== MEASURED: 3 × ABBA ===

--- cycle 1 position 1/4 generic ---
[C1 P1] generic n=2560 0.000436115 ms
[C1 P1] generic n=3200 0.000639534 ms
[C1 P1] generic n=6912 0.001159668 ms
[C1 P1] generic n=8192 0.001369476 ms

--- cycle 1 position 2/4 handwritten ---
[C1 P2] handwritten n=2560 0.000227594 ms
[C1 P2] handwritten n=3200 0.000273418 ms
[C1 P2] handwritten n=6912 0.000589561 ms
[C1 P2] handwritten n=8192 0.000716591 ms

--- cycle 1 position 3/4 handwritten ---
[C1 P3] handwritten n=2560 0.000224924 ms
[C1 P3] handwritten n=3200 0.000275135 ms
[C1 P3] handwritten n=6912 0.000614166 ms
[C1 P3] handwritten n=8192 0.000741386 ms

--- cycle 1 position 4/4 generic ---
[C1 P4] generic n=2560 0.000435638 ms
[C1 P4] generic n=3200 0.000535965 ms
[C1 P4] generic n=6912 0.001141357 ms
[C1 P4] generic n=8192 0.001377869 ms

--- cycle 2 position 1/4 generic ---
[C2 P1] generic n=2560 0.000433064 ms
[C2 P1] generic n=3200 0.000608444 ms
[C2 P1] generic n=6912 0.001192856 ms
[C2 P1] generic n=8192 0.001622772 ms

--- cycle 2 position 2/4 handwritten ---
[C2 P2] handwritten n=2560 0.000219917 ms
[C2 P2] handwritten n=3200 0.000280190 ms
[C2 P2] handwritten n=6912 0.000583076 ms
[C2 P2] handwritten n=8192 0.000697899 ms

--- cycle 2 position 3/4 handwritten ---
[C2 P3] handwritten n=2560 0.000221348 ms
[C2 P3] handwritten n=3200 0.000274563 ms
[C2 P3] handwritten n=6912 0.000588036 ms
[C2 P3] handwritten n=8192 0.001036835 ms

--- cycle 2 position 4/4 generic ---
[C2 P4] generic n=2560 0.000437927 ms
[C2 P4] generic n=3200 0.000545883 ms
[C2 P4] generic n=6912 0.001168060 ms
[C2 P4] generic n=8192 0.001403809 ms

--- cycle 3 position 1/4 generic ---
[C3 P1] generic n=2560 0.000432587 ms
[C3 P1] generic n=3200 0.000544739 ms
[C3 P1] generic n=6912 0.001193619 ms
[C3 P1] generic n=8192 0.001585388 ms

--- cycle 3 position 2/4 handwritten ---
[C3 P2] handwritten n=2560 0.000617790 ms
[C3 P2] handwritten n=3200 0.000776482 ms
[C3 P2] handwritten n=6912 0.001639557 ms
[C3 P2] handwritten n=8192 0.001958084 ms

--- cycle 3 position 3/4 handwritten ---
[C3 P3] handwritten n=2560 0.000630760 ms
[C3 P3] handwritten n=3200 0.000876045 ms
[C3 P3] handwritten n=6912 0.001675034 ms
[C3 P3] handwritten n=8192 0.001959229 ms

--- cycle 3 position 4/4 generic ---
[C3 P4] generic n=2560 0.000383759 ms
[C3 P4] generic n=3200 0.000435734 ms
[C3 P4] generic n=6912 0.000925827 ms
[C3 P4] generic n=8192 0.001119232 ms

=== FINAL STABILITY RESULT ===
n=2560 speedup=1.920x G-CV=4.93% H-CV=57.99%
  cycle 1: 1.926x
  cycle 2: 1.974x
  cycle 3: 0.654x
n=3200 speedup=1.964x G-CV=12.74% H-CV=62.27%
  cycle 1: 2.143x
  cycle 2: 2.081x
  cycle 3: 0.593x
n=6912 speedup=1.934x G-CV=9.04% H-CV=57.94%
  cycle 1: 1.912x
  cycle 2: 2.016x
  cycle 3: 0.639x
n=8192 speedup=1.564x G-CV=12.79% H-CV=51.64%
  cycle 1: 1.884x
  cycle 2: 1.745x
  cycle 3: 0.690x

cycle 1 geomean: 1.964x
cycle 2 geomean: 1.950x
cycle 3 geomean: 0.643x
overall geomean: 1.838x

{
  "schema": "p1-browser-microkernel-stability-v2",
  "timestamp": "2026-09-13T20:44:42.889Z",
  "browser": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36",
  "hardware_concurrency": 8,
  "device_memory_gb": 32,
  "cross_origin_isolated": false,
  "implementation": {
    "generic": "Clang/Emscripten autovectorized WASM SIMD128",
    "handwritten": "Explicit WASM SIMD128 using i32x4.dot_i16x8_s"
  },
  "protocol": {
    "priming_order": [
      "generic",
      "handwritten",
      "generic",
      "handwritten"
    ],
    "priming_workers": 4,
    "priming_included_in_results": false,
    "measured_cycles": 3,
    "order_per_cycle": [
      "generic",
      "handwritten",
      "handwritten",
      "generic"
    ],
    "total_measured_workers": 12,
    "measured_workers_per_implementation": 6,
    "fresh_worker_per_position": true,
    "outliers_removed": false
  },
  "rows": [
    {
      "n": 2560,
      "generic_samples_ms": [
        0.000436115,
        0.000435638,
        0.000433064,
        0.000437927,
        0.000432587,
        0.000383759
      ],
      "handwritten_samples_ms": [
        0.000227594,
        0.000224924,
        0.000219917,
        0.000221348,
        0.00061779,
        0.00063076
      ],
      "generic_median_ms": 0.00043435100000000003,
      "handwritten_median_ms": 0.00022625899999999998,
      "generic_mean_ms": 0.000426515,
      "handwritten_mean_ms": 0.00035705549999999996,
      "generic_stddev_ms": 0.000021040232859928143,
      "handwritten_stddev_ms": 0.00020704547318089328,
      "generic_cv": 0.0493305812455087,
      "handwritten_cv": 0.5798691609032582,
      "generic_min_ms": 0.000383759,
      "generic_max_ms": 0.000437927,
      "handwritten_min_ms": 0.000219917,
      "handwritten_max_ms": 0.00063076,
      "speedup": 1.9197070613765643,
      "cycles": [
        {
          "cycle": 1,
          "generic_median_ms": 0.00043587650000000003,
          "handwritten_median_ms": 0.00022625899999999998,
          "speedup": 1.926449334612104
        },
        {
          "cycle": 2,
          "generic_median_ms": 0.0004354955,
          "handwritten_median_ms": 0.00022063250000000002,
          "speedup": 1.9738501807303999
        },
        {
          "cycle": 3,
          "generic_median_ms": 0.000408173,
          "handwritten_median_ms": 0.000624275,
          "speedup": 0.6538352488887109
        }
      ]
    },
    {
      "n": 3200,
      "generic_samples_ms": [
        0.000639534,
        0.000535965,
        0.000608444,
        0.000545883,
        0.000544739,
        0.000435734
      ],
      "handwritten_samples_ms": [
        0.000273418,
        0.000275135,
        0.00028019,
        0.000274563,
        0.000776482,
        0.000876045
      ],
      "generic_median_ms": 0.000545311,
      "handwritten_median_ms": 0.0002776625,
      "generic_mean_ms": 0.0005517165,
      "handwritten_mean_ms": 0.00045930550000000003,
      "generic_stddev_ms": 0.00007030318321313765,
      "handwritten_stddev_ms": 0.00028599224898080716,
      "generic_cv": 0.127426283631426,
      "handwritten_cv": 0.622662365203132,
      "generic_min_ms": 0.000435734,
      "generic_max_ms": 0.000639534,
      "handwritten_min_ms": 0.000273418,
      "handwritten_max_ms": 0.000876045,
      "speedup": 1.9639346328726424,
      "cycles": [
        {
          "cycle": 1,
          "generic_median_ms": 0.0005877495,
          "handwritten_median_ms": 0.0002742765,
          "speedup": 2.142908707089379
        },
        {
          "cycle": 2,
          "generic_median_ms": 0.0005771635000000001,
          "handwritten_median_ms": 0.00027737650000000003,
          "speedup": 2.0807945157574634
        },
        {
          "cycle": 3,
          "generic_median_ms": 0.0004902365,
          "handwritten_median_ms": 0.0008262635,
          "speedup": 0.5933173860396834
        }
      ]
    },
    {
      "n": 6912,
      "generic_samples_ms": [
        0.001159668,
        0.001141357,
        0.001192856,
        0.00116806,
        0.001193619,
        0.000925827
      ],
      "handwritten_samples_ms": [
        0.000589561,
        0.000614166,
        0.000583076,
        0.000588036,
        0.001639557,
        0.001675034
      ],
      "generic_median_ms": 0.0011638640000000001,
      "handwritten_median_ms": 0.0006018635,
      "generic_mean_ms": 0.0011302311666666666,
      "handwritten_mean_ms": 0.0009482383333333333,
      "generic_stddev_ms": 0.00010211981440526937,
      "handwritten_stddev_ms": 0.0005494536275132476,
      "generic_cv": 0.09035303344752574,
      "handwritten_cv": 0.5794467574220065,
      "generic_min_ms": 0.000925827,
      "generic_max_ms": 0.001193619,
      "handwritten_min_ms": 0.000583076,
      "handwritten_max_ms": 0.001675034,
      "speedup": 1.9337673741637436,
      "cycles": [
        {
          "cycle": 1,
          "generic_median_ms": 0.0011505125,
          "handwritten_median_ms": 0.0006018635,
          "speedup": 1.9115837727325216
        },
        {
          "cycle": 2,
          "generic_median_ms": 0.0011804580000000001,
          "handwritten_median_ms": 0.000585556,
          "speedup": 2.0159608987014055
        },
        {
          "cycle": 3,
          "generic_median_ms": 0.001059723,
          "handwritten_median_ms": 0.0016572955,
          "speedup": 0.6394291181023541
        }
      ]
    },
    {
      "n": 8192,
      "generic_samples_ms": [
        0.001369476,
        0.001377869,
        0.001622772,
        0.001403809,
        0.001585388,
        0.001119232
      ],
      "handwritten_samples_ms": [
        0.000716591,
        0.000741386,
        0.000697899,
        0.001036835,
        0.001958084,
        0.001959229
      ],
      "generic_median_ms": 0.001390839,
      "handwritten_median_ms": 0.0008891105,
      "generic_mean_ms": 0.001413091,
      "handwritten_mean_ms": 0.001185004,
      "generic_stddev_ms": 0.0001806845333081944,
      "handwritten_stddev_ms": 0.0006119656917024025,
      "generic_cv": 0.12786475415114412,
      "handwritten_cv": 0.5164250008459065,
      "generic_min_ms": 0.001119232,
      "generic_max_ms": 0.001622772,
      "handwritten_min_ms": 0.000697899,
      "handwritten_max_ms": 0.001959229,
      "speedup": 1.5643038744902913,
      "cycles": [
        {
          "cycle": 1,
          "generic_median_ms": 0.0013736725,
          "handwritten_median_ms": 0.0007289885,
          "speedup": 1.8843541427608255
        },
        {
          "cycle": 2,
          "generic_median_ms": 0.0015132905,
          "handwritten_median_ms": 0.000867367,
          "speedup": 1.744694575652521
        },
        {
          "cycle": 3,
          "generic_median_ms": 0.00135231,
          "handwritten_median_ms": 0.0019586565,
          "speedup": 0.6904273413944712
        }
      ]
    }
  ],
  "geometric_mean_speedup": 1.8376882360091589,
  "cycle_geometric_mean_speedups": [
    {
      "cycle": 1,
      "geometric_mean_speedup": 1.963718722357469
    },
    {
      "cycle": 2,
      "geometric_mean_speedup": 1.9495582861359224
    },
    {
      "cycle": 3,
      "geometric_mean_speedup": 0.6433042918528687
    }
  ],
  "suite_wall_ms": 380432
}
```