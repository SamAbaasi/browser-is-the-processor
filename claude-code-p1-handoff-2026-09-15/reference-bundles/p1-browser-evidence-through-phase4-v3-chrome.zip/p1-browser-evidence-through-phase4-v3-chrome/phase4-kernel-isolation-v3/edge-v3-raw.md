```
=== PRIMING — NOT MEASURED ===
[prime 1/4] generic n=2560 0.000446987 ms
[prime 1/4] generic n=3200 0.000546646 ms
[prime 1/4] generic n=6912 0.001313782 ms
[prime 1/4] generic n=8192 0.001445007 ms
[prime 2/4] handwritten n=2560 0.000223637 ms
[prime 2/4] handwritten n=3200 0.000274563 ms
[prime 2/4] handwritten n=6912 0.000587273 ms
[prime 2/4] handwritten n=8192 0.000704956 ms
[prime 3/4] generic n=2560 0.000449371 ms
[prime 3/4] generic n=3200 0.000544930 ms
[prime 3/4] generic n=6912 0.001178360 ms
[prime 3/4] generic n=8192 0.001669693 ms
[prime 4/4] handwritten n=2560 0.000252151 ms
[prime 4/4] handwritten n=3200 0.000299549 ms
[prime 4/4] handwritten n=6912 0.000598907 ms
[prime 4/4] handwritten n=8192 0.000694084 ms

=== MEASURED: 3 × ABBA ===

--- cycle 1 position 1/4 generic ---
[C1 P1] generic n=2560 0.000439167 ms
[C1 P1] generic n=3200 0.000549316 ms
[C1 P1] generic n=6912 0.001190948 ms
[C1 P1] generic n=8192 0.001422501 ms

--- cycle 1 position 2/4 handwritten ---
[C1 P2] handwritten n=2560 0.000222921 ms
[C1 P2] handwritten n=3200 0.000282288 ms
[C1 P2] handwritten n=6912 0.000601387 ms
[C1 P2] handwritten n=8192 0.000712395 ms

--- cycle 1 position 3/4 handwritten ---
[C1 P3] handwritten n=2560 0.000222683 ms
[C1 P3] handwritten n=3200 0.000360394 ms
[C1 P3] handwritten n=6912 0.000597191 ms
[C1 P3] handwritten n=8192 0.000705910 ms

--- cycle 1 position 4/4 generic ---
[C1 P4] generic n=2560 0.000435448 ms
[C1 P4] generic n=3200 0.000545311 ms
[C1 P4] generic n=6912 0.001176453 ms
[C1 P4] generic n=8192 0.001437759 ms

--- cycle 2 position 1/4 generic ---
[C2 P1] generic n=2560 0.000525665 ms
[C2 P1] generic n=3200 0.000577164 ms
[C2 P1] generic n=6912 0.001185989 ms
[C2 P1] generic n=8192 0.001402664 ms

--- cycle 2 position 2/4 handwritten ---
[C2 P2] handwritten n=2560 0.000223541 ms
[C2 P2] handwritten n=3200 0.000278854 ms
[C2 P2] handwritten n=6912 0.000600624 ms
[C2 P2] handwritten n=8192 0.000716209 ms

--- cycle 2 position 3/4 handwritten ---
[C2 P3] handwritten n=2560 0.000256348 ms
[C2 P3] handwritten n=3200 0.000276470 ms
[C2 P3] handwritten n=6912 0.000586510 ms
[C2 P3] handwritten n=8192 0.000694466 ms

--- cycle 2 position 4/4 generic ---
[C2 P4] generic n=2560 0.001187515 ms
[C2 P4] generic n=3200 0.001491165 ms
[C2 P4] generic n=6912 0.003219604 ms
[C2 P4] generic n=8192 0.003980255 ms

--- cycle 3 position 1/4 generic ---
[C3 P1] generic n=2560 0.001200485 ms
[C3 P1] generic n=3200 0.001497650 ms
[C3 P1] generic n=6912 0.003210449 ms
[C3 P1] generic n=8192 0.003796387 ms

--- cycle 3 position 2/4 handwritten ---
[C3 P2] handwritten n=2560 0.000612450 ms
[C3 P2] handwritten n=3200 0.000767326 ms
[C3 P2] handwritten n=6912 0.001636505 ms
[C3 P2] handwritten n=8192 0.001964569 ms

--- cycle 3 position 3/4 handwritten ---
[C3 P3] handwritten n=2560 0.000597954 ms
[C3 P3] handwritten n=3200 0.000765038 ms
[C3 P3] handwritten n=6912 0.001634979 ms
[C3 P3] handwritten n=8192 0.001982498 ms

--- cycle 3 position 4/4 generic ---
[C3 P4] generic n=2560 0.001165009 ms
[C3 P4] generic n=3200 0.001497650 ms
[C3 P4] generic n=6912 0.003321075 ms
[C3 P4] generic n=8192 0.004267883 ms

=== FINAL STABILITY RESULT ===
n=2560 speedup=3.523x G-CV=47.79% H-CV=54.36%
  cycle 1: 1.963x
  cycle 2: 3.570x
  cycle 3: 1.954x
n=3200 speedup=3.218x G-CV=50.08% H-CV=53.41%
  cycle 1: 1.703x
  cycle 2: 3.725x
  cycle 3: 1.955x
n=6912 speedup=3.662x G-CV=51.06% H-CV=56.92%
  cycle 1: 1.975x
  cycle 2: 3.711x
  cycle 3: 1.997x
n=8192 speedup=3.664x G-CV=52.57% H-CV=57.91%
  cycle 1: 2.017x
  cycle 2: 3.816x
  cycle 3: 2.043x

cycle 1 geomean: 1.910x
cycle 2 geomean: 3.704x
cycle 3 geomean: 1.987x
overall geomean: 3.512x

{
  "schema": "p1-browser-microkernel-stability-v2",
  "timestamp": "2026-09-13T20:23:59.982Z",
  "browser": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0",
  "hardware_concurrency": 8,
  "device_memory_gb": 32,
  "cross_origin_isolated": false,
  "implementation": {
    "generic": "Clang/Emscripten autovectorized WASM SIMD128",
    "handwritten": "Explicit WASM SIMD128 using i32x4.dot_i16x8_s"
  },
  "protocol": {
    "priming_order": [
      "generic",
      "handwritten",
      "generic",
      "handwritten"
    ],
    "priming_workers": 4,
    "priming_included_in_results": false,
    "measured_cycles": 3,
    "order_per_cycle": [
      "generic",
      "handwritten",
      "handwritten",
      "generic"
    ],
    "total_measured_workers": 12,
    "measured_workers_per_implementation": 6,
    "fresh_worker_per_position": true,
    "outliers_removed": false
  },
  "rows": [
    {
      "n": 2560,
      "generic_samples_ms": [
        0.000439167,
        0.000435448,
        0.000525665,
        0.001187515,
        0.001200485,
        0.001165009
      ],
      "handwritten_samples_ms": [
        0.000222921,
        0.000222683,
        0.000223541,
        0.000256348,
        0.00061245,
        0.000597954
      ],
      "generic_median_ms": 0.000845337,
      "handwritten_median_ms": 0.0002399445,
      "generic_mean_ms": 0.0008255481666666667,
      "handwritten_mean_ms": 0.0003559828333333333,
      "generic_stddev_ms": 0.00039451989415714727,
      "handwritten_stddev_ms": 0.00019352916543138055,
      "generic_cv": 0.4778884020179084,
      "handwritten_cv": 0.5436474664219686,
      "generic_min_ms": 0.000435448,
      "generic_max_ms": 0.001200485,
      "handwritten_min_ms": 0.000222683,
      "handwritten_max_ms": 0.00061245,
      "speedup": 3.5230522058225966,
      "cycles": [
        {
          "cycle": 1,
          "generic_median_ms": 0.0004373075,
          "handwritten_median_ms": 0.000222802,
          "speedup": 1.9627629015897523
        },
        {
          "cycle": 2,
          "generic_median_ms": 0.0008565900000000001,
          "handwritten_median_ms": 0.0002399445,
          "speedup": 3.569950551064934
        },
        {
          "cycle": 3,
          "generic_median_ms": 0.001182747,
          "handwritten_median_ms": 0.000605202,
          "speedup": 1.9543012085221134
        }
      ]
    },
    {
      "n": 3200,
      "generic_samples_ms": [
        0.000549316,
        0.000545311,
        0.000577164,
        0.001491165,
        0.00149765,
        0.00149765
      ],
      "handwritten_samples_ms": [
        0.000282288,
        0.000360394,
        0.000278854,
        0.00027647,
        0.000767326,
        0.000765038
      ],
      "generic_median_ms": 0.0010341645,
      "handwritten_median_ms": 0.000321341,
      "generic_mean_ms": 0.0010263759999999999,
      "handwritten_mean_ms": 0.0004550616666666667,
      "generic_stddev_ms": 0.0005140094122566239,
      "handwritten_stddev_ms": 0.00024304368878838773,
      "generic_cv": 0.5008003034527541,
      "handwritten_cv": 0.5340895676154976,
      "generic_min_ms": 0.000545311,
      "generic_max_ms": 0.00149765,
      "handwritten_min_ms": 0.00027647,
      "handwritten_max_ms": 0.000767326,
      "speedup": 3.2182774684836355,
      "cycles": [
        {
          "cycle": 1,
          "generic_median_ms": 0.0005473135,
          "handwritten_median_ms": 0.000321341,
          "speedup": 1.7032171431594474
        },
        {
          "cycle": 2,
          "generic_median_ms": 0.0010341645,
          "handwritten_median_ms": 0.000277662,
          "speedup": 3.7245445901851886
        },
        {
          "cycle": 3,
          "generic_median_ms": 0.00149765,
          "handwritten_median_ms": 0.000766182,
          "speedup": 1.954692227173178
        }
      ]
    },
    {
      "n": 6912,
      "generic_samples_ms": [
        0.001190948,
        0.001176453,
        0.001185989,
        0.003219604,
        0.003210449,
        0.003321075
      ],
      "handwritten_samples_ms": [
        0.000601387,
        0.000597191,
        0.000600624,
        0.00058651,
        0.001636505,
        0.001634979
      ],
      "generic_median_ms": 0.0022006985000000002,
      "handwritten_median_ms": 0.0006010055,
      "generic_mean_ms": 0.0022174196666666667,
      "handwritten_mean_ms": 0.000942866,
      "generic_stddev_ms": 0.0011322226541944243,
      "handwritten_stddev_ms": 0.000536725957161753,
      "generic_cv": 0.5106036855425011,
      "handwritten_cv": 0.5692494555554586,
      "generic_min_ms": 0.001176453,
      "generic_max_ms": 0.003321075,
      "handwritten_min_ms": 0.00058651,
      "handwritten_max_ms": 0.001636505,
      "speedup": 3.6616944437280528,
      "cycles": [
        {
          "cycle": 1,
          "generic_median_ms": 0.0011837005,
          "handwritten_median_ms": 0.000599289,
          "speedup": 1.975174748743928
        },
        {
          "cycle": 2,
          "generic_median_ms": 0.0022027965,
          "handwritten_median_ms": 0.000593567,
          "speedup": 3.711116857911575
        },
        {
          "cycle": 3,
          "generic_median_ms": 0.003265762,
          "handwritten_median_ms": 0.001635742,
          "speedup": 1.9965018933303664
        }
      ]
    },
    {
      "n": 8192,
      "generic_samples_ms": [
        0.001422501,
        0.001437759,
        0.001402664,
        0.003980255,
        0.003796387,
        0.004267883
      ],
      "handwritten_samples_ms": [
        0.000712395,
        0.00070591,
        0.000716209,
        0.000694466,
        0.001964569,
        0.001982498
      ],
      "generic_median_ms": 0.002617073,
      "handwritten_median_ms": 0.000714302,
      "generic_mean_ms": 0.002717908166666667,
      "handwritten_mean_ms": 0.0011293411666666666,
      "generic_stddev_ms": 0.0014286907950890446,
      "handwritten_stddev_ms": 0.0006539747353466851,
      "generic_cv": 0.525658229593989,
      "handwritten_cv": 0.5790763275520537,
      "generic_min_ms": 0.001402664,
      "generic_max_ms": 0.004267883,
      "handwritten_min_ms": 0.000694466,
      "handwritten_max_ms": 0.001982498,
      "speedup": 3.6638186649344395,
      "cycles": [
        {
          "cycle": 1,
          "generic_median_ms": 0.00143013,
          "handwritten_median_ms": 0.0007091525,
          "speedup": 2.01667483369233
        },
        {
          "cycle": 2,
          "generic_median_ms": 0.0026914595,
          "handwritten_median_ms": 0.0007053375000000001,
          "speedup": 3.815846314707498
        },
        {
          "cycle": 3,
          "generic_median_ms": 0.004032135,
          "handwritten_median_ms": 0.0019735335,
          "speedup": 2.0431044114528585
        }
      ]
    }
  ],
  "geometric_mean_speedup": 3.511879927734006,
  "cycle_geometric_mean_speedups": [
    {
      "cycle": 1,
      "geometric_mean_speedup": 1.910270266843736
    },
    {
      "cycle": 2,
      "geometric_mean_speedup": 3.7043133846597094
    },
    {
      "cycle": 3,
      "geometric_mean_speedup": 1.9868155190703964
    }
  ],
  "suite_wall_ms": 387782.59999996424
}
```