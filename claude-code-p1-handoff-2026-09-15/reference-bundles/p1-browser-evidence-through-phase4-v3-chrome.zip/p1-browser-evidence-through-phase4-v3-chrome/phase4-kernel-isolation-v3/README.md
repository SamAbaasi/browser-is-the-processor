# Phase 4B v3 — Same-worker prewarm

The v3 worker performs one complete `p1-i2s-bench` run inside the Worker and discards it,
then performs a second complete run in the same Worker/WASM instance and records that result.

Important: the HTML still emits schema `p1-browser-microkernel-stability-v2`; this bundle
labels the experiment v3 based on worker behavior.

## Edge 152

- pooled geomean reported by page: 3.512x
- cycle geomeans: 1.910x, 3.704x, 1.987x
- geometric mean of cycle geomeans: 2.414x
- very high worker-to-worker CV remains (~48-58% on many rows).

Conclusion: same-worker prewarming did **not** fix Edge variability.

## Firefox 150

- pooled geomean: 1.214x
- cycle geomeans: 1.232x, 1.243x, 1.225x
- geometric mean of cycle geomeans: 1.233x

Firefox remains close to ~1.21x and comparatively stable.

## Next

Do not add more fresh-worker ABBA repetitions yet. The next useful experiment is to isolate
Edge worker/process scheduling and CPU performance-state effects with long-lived workers and
system/core information.
