```
=== PRIMING — NOT MEASURED ===
[prime 1/4] generic n=2560 0.000277519 ms
[prime 1/4] generic n=3200 0.000329018 ms
[prime 1/4] generic n=6912 0.000703812 ms
[prime 1/4] generic n=8192 0.000822067 ms
[prime 2/4] handwritten n=2560 0.000212193 ms
[prime 2/4] handwritten n=3200 0.000258446 ms
[prime 2/4] handwritten n=6912 0.000598907 ms
[prime 2/4] handwritten n=8192 0.000694275 ms
[prime 3/4] generic n=2560 0.000257492 ms
[prime 3/4] generic n=3200 0.000315666 ms
[prime 3/4] generic n=6912 0.000688553 ms
[prime 3/4] generic n=8192 0.000808716 ms
[prime 4/4] handwritten n=2560 0.000213146 ms
[prime 4/4] handwritten n=3200 0.000258446 ms
[prime 4/4] handwritten n=6912 0.000566483 ms
[prime 4/4] handwritten n=8192 0.000663757 ms

=== MEASURED: 3 × ABBA ===

--- cycle 1 position 1/4 generic ---
[C1 P1] generic n=2560 0.000260353 ms
[C1 P1] generic n=3200 0.000320435 ms
[C1 P1] generic n=6912 0.000688553 ms
[C1 P1] generic n=8192 0.000802994 ms

--- cycle 1 position 2/4 handwritten ---
[C1 P2] handwritten n=2560 0.000209332 ms
[C1 P2] handwritten n=3200 0.000258446 ms
[C1 P2] handwritten n=6912 0.000593185 ms
[C1 P2] handwritten n=8192 0.000688553 ms

--- cycle 1 position 3/4 handwritten ---
[C1 P3] handwritten n=2560 0.000212669 ms
[C1 P3] handwritten n=3200 0.000265121 ms
[C1 P3] handwritten n=6912 0.000570297 ms
[C1 P3] handwritten n=8192 0.000684738 ms

--- cycle 1 position 4/4 generic ---
[C1 P4] generic n=2560 0.000268936 ms
[C1 P4] generic n=3200 0.000323296 ms
[C1 P4] generic n=6912 0.000709534 ms
[C1 P4] generic n=8192 0.000905991 ms

--- cycle 2 position 1/4 generic ---
[C2 P1] generic n=2560 0.000261307 ms
[C2 P1] generic n=3200 0.000324249 ms
[C2 P1] generic n=6912 0.000680923 ms
[C2 P1] generic n=8192 0.000818253 ms

--- cycle 2 position 2/4 handwritten ---
[C2 P2] handwritten n=2560 0.000215054 ms
[C2 P2] handwritten n=3200 0.000267029 ms
[C2 P2] handwritten n=6912 0.000591278 ms
[C2 P2] handwritten n=8192 0.000684738 ms

--- cycle 2 position 3/4 handwritten ---
[C2 P3] handwritten n=2560 0.000213623 ms
[C2 P3] handwritten n=3200 0.000267029 ms
[C2 P3] handwritten n=6912 0.000562668 ms
[C2 P3] handwritten n=8192 0.000761032 ms

--- cycle 2 position 4/4 generic ---
[C2 P4] generic n=2560 0.000296593 ms
[C2 P4] generic n=3200 0.000323296 ms
[C2 P4] generic n=6912 0.000816345 ms
[C2 P4] generic n=8192 0.000865936 ms

--- cycle 3 position 1/4 generic ---
[C3 P1] generic n=2560 0.000259399 ms
[C3 P1] generic n=3200 0.000325203 ms
[C3 P1] generic n=6912 0.000707626 ms
[C3 P1] generic n=8192 0.000822067 ms

--- cycle 3 position 2/4 handwritten ---
[C3 P2] handwritten n=2560 0.000213146 ms
[C3 P2] handwritten n=3200 0.000286102 ms
[C3 P2] handwritten n=6912 0.000682831 ms
[C3 P2] handwritten n=8192 0.000680923 ms

--- cycle 3 position 3/4 handwritten ---
[C3 P3] handwritten n=2560 0.000214100 ms
[C3 P3] handwritten n=3200 0.000267029 ms
[C3 P3] handwritten n=6912 0.000570297 ms
[C3 P3] handwritten n=8192 0.000677109 ms

--- cycle 3 position 4/4 generic ---
[C3 P4] generic n=2560 0.000262260 ms
[C3 P4] generic n=3200 0.000331879 ms
[C3 P4] generic n=6912 0.000907898 ms
[C3 P4] generic n=8192 0.000812531 ms

=== FINAL STABILITY RESULT ===
n=2560 speedup=1.227x G-CV=5.35% H-CV=0.92%
  cycle 1: 1.254x
  cycle 2: 1.301x
  cycle 3: 1.221x
n=3200 speedup=1.212x G-CV=1.19% H-CV=3.45%
  cycle 1: 1.230x
  cycle 2: 1.212x
  cycle 3: 1.188x
n=6912 speedup=1.220x G-CV=12.09% H-CV=7.51%
  cycle 1: 1.202x
  cycle 2: 1.298x
  cycle 3: 1.289x
n=8192 speedup=1.198x G-CV=4.75% H-CV=4.60%
  cycle 1: 1.244x
  cycle 2: 1.165x
  cycle 3: 1.204x

cycle 1 geomean: 1.232x
cycle 2 geomean: 1.243x
cycle 3 geomean: 1.225x
overall geomean: 1.214x

{
  "schema": "p1-browser-microkernel-stability-v2",
  "timestamp": "2026-09-13T20:33:03.787Z",
  "browser": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
  "hardware_concurrency": 8,
  "device_memory_gb": null,
  "cross_origin_isolated": false,
  "implementation": {
    "generic": "Clang/Emscripten autovectorized WASM SIMD128",
    "handwritten": "Explicit WASM SIMD128 using i32x4.dot_i16x8_s"
  },
  "protocol": {
    "priming_order": [
      "generic",
      "handwritten",
      "generic",
      "handwritten"
    ],
    "priming_workers": 4,
    "priming_included_in_results": false,
    "measured_cycles": 3,
    "order_per_cycle": [
      "generic",
      "handwritten",
      "handwritten",
      "generic"
    ],
    "total_measured_workers": 12,
    "measured_workers_per_implementation": 6,
    "fresh_worker_per_position": true,
    "outliers_removed": false
  },
  "rows": [
    {
      "n": 2560,
      "generic_samples_ms": [
        0.000260353,
        0.000268936,
        0.000261307,
        0.000296593,
        0.000259399,
        0.00026226
      ],
      "handwritten_samples_ms": [
        0.000209332,
        0.000212669,
        0.000215054,
        0.000213623,
        0.000213146,
        0.0002141
      ],
      "generic_median_ms": 0.0002617835,
      "handwritten_median_ms": 0.0002133845,
      "generic_mean_ms": 0.0002681413333333334,
      "handwritten_mean_ms": 0.00021298733333333336,
      "generic_stddev_ms": 0.000014342339790517676,
      "handwritten_stddev_ms": 0.000001969831634091264,
      "generic_cv": 0.053487985653775896,
      "handwritten_cv": 0.009248585834953865,
      "generic_min_ms": 0.000259399,
      "generic_max_ms": 0.000296593,
      "handwritten_min_ms": 0.000209332,
      "handwritten_max_ms": 0.000215054,
      "speedup": 1.226815912121077,
      "cycles": [
        {
          "cycle": 1,
          "generic_median_ms": 0.00026464450000000003,
          "handwritten_median_ms": 0.0002110005,
          "speedup": 1.254236364368805
        },
        {
          "cycle": 2,
          "generic_median_ms": 0.00027895000000000003,
          "handwritten_median_ms": 0.00021433850000000001,
          "speedup": 1.301446077116337
        },
        {
          "cycle": 3,
          "generic_median_ms": 0.00026082950000000003,
          "handwritten_median_ms": 0.000213623,
          "speedup": 1.220980418775132
        }
      ]
    },
    {
      "n": 3200,
      "generic_samples_ms": [
        0.000320435,
        0.000323296,
        0.000324249,
        0.000323296,
        0.000325203,
        0.000331879
      ],
      "handwritten_samples_ms": [
        0.000258446,
        0.000265121,
        0.000267029,
        0.000267029,
        0.000286102,
        0.000267029
      ],
      "generic_median_ms": 0.0003237725,
      "handwritten_median_ms": 0.000267029,
      "generic_mean_ms": 0.00032472633333333333,
      "handwritten_mean_ms": 0.0002684593333333333,
      "generic_stddev_ms": 0.000003850271349744931,
      "handwritten_stddev_ms": 0.000009260805162979435,
      "generic_cv": 0.011856972947717816,
      "handwritten_cv": 0.034496119199851884,
      "generic_min_ms": 0.000320435,
      "generic_max_ms": 0.000331879,
      "handwritten_min_ms": 0.000258446,
      "handwritten_max_ms": 0.000286102,
      "speedup": 1.2124993914518647,
      "cycles": [
        {
          "cycle": 1,
          "generic_median_ms": 0.0003218655,
          "handwritten_median_ms": 0.0002617835,
          "speedup": 1.2295102632518857
        },
        {
          "cycle": 2,
          "generic_median_ms": 0.0003237725,
          "handwritten_median_ms": 0.000267029,
          "speedup": 1.2124993914518647
        },
        {
          "cycle": 3,
          "generic_median_ms": 0.000328541,
          "handwritten_median_ms": 0.0002765655,
          "speedup": 1.1879319727153244
        }
      ]
    },
    {
      "n": 6912,
      "generic_samples_ms": [
        0.000688553,
        0.000709534,
        0.000680923,
        0.000816345,
        0.000707626,
        0.000907898
      ],
      "handwritten_samples_ms": [
        0.000593185,
        0.000570297,
        0.000591278,
        0.000562668,
        0.000682831,
        0.000570297
      ],
      "generic_median_ms": 0.00070858,
      "handwritten_median_ms": 0.0005807875,
      "generic_mean_ms": 0.0007518131666666666,
      "handwritten_mean_ms": 0.0005950926666666666,
      "generic_stddev_ms": 0.00009087808400140633,
      "handwritten_stddev_ms": 0.000044715132090453065,
      "generic_cv": 0.12087854806312429,
      "handwritten_cv": 0.07513978006302616,
      "generic_min_ms": 0.000680923,
      "generic_max_ms": 0.000907898,
      "handwritten_min_ms": 0.000562668,
      "handwritten_max_ms": 0.000682831,
      "speedup": 1.2200331446527344,
      "cycles": [
        {
          "cycle": 1,
          "generic_median_ms": 0.0006990435,
          "handwritten_median_ms": 0.000581741,
          "speedup": 1.2016404207370635
        },
        {
          "cycle": 2,
          "generic_median_ms": 0.000748634,
          "handwritten_median_ms": 0.0005769729999999999,
          "speedup": 1.297519987937044
        },
        {
          "cycle": 3,
          "generic_median_ms": 0.0008077620000000001,
          "handwritten_median_ms": 0.000626564,
          "speedup": 1.2891931231286828
        }
      ]
    },
    {
      "n": 8192,
      "generic_samples_ms": [
        0.000802994,
        0.000905991,
        0.000818253,
        0.000865936,
        0.000822067,
        0.000812531
      ],
      "handwritten_samples_ms": [
        0.000688553,
        0.000684738,
        0.000684738,
        0.000761032,
        0.000680923,
        0.000677109
      ],
      "generic_median_ms": 0.00082016,
      "handwritten_median_ms": 0.000684738,
      "generic_mean_ms": 0.0008379619999999999,
      "handwritten_mean_ms": 0.0006961821666666666,
      "generic_stddev_ms": 0.00003980221603880868,
      "handwritten_stddev_ms": 0.00003200709553468837,
      "generic_cv": 0.04749883173557832,
      "handwritten_cv": 0.04597517297511217,
      "generic_min_ms": 0.000802994,
      "generic_max_ms": 0.000905991,
      "handwritten_min_ms": 0.000677109,
      "handwritten_max_ms": 0.000761032,
      "speedup": 1.1977719945438987,
      "cycles": [
        {
          "cycle": 1,
          "generic_median_ms": 0.0008544925,
          "handwritten_median_ms": 0.0006866455,
          "speedup": 1.2444449137145732
        },
        {
          "cycle": 2,
          "generic_median_ms": 0.0008420945,
          "handwritten_median_ms": 0.0007228849999999999,
          "speedup": 1.1649079729140874
        },
        {
          "cycle": 3,
          "generic_median_ms": 0.0008172990000000001,
          "handwritten_median_ms": 0.000679016,
          "speedup": 1.2036520494362433
        }
      ]
    }
  ],
  "geometric_mean_speedup": 1.2142320117830634,
  "cycle_geometric_mean_speedups": [
    {
      "cycle": 1,
      "geometric_mean_speedup": 1.2322971329611563
    },
    {
      "cycle": 2,
      "geometric_mean_speedup": 1.2427344728096603
    },
    {
      "cycle": 3,
      "geometric_mean_speedup": 1.2248412458821263
    }
  ],
  "suite_wall_ms": 365345
}
```