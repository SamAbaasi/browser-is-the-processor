```
================================
ABBA prefill-64
model: ggml-model-i2_s.gguf
bytes: 1844472032
order: generic -> handwritten -> handwritten -> generic

--- run 1/4: generic ---
[1/4] generic model load: 5421.0 ms
[1/4] generic warmup done
[1/4] generic rep 0: 14433.0 ms (4.434 t/s)
[1/4] generic rep 1: 14319.0 ms (4.470 t/s)
[1/4] generic rep 2: 14492.0 ms (4.416 t/s)

--- run 2/4: handwritten ---
[2/4] handwritten model load: 6808.0 ms
[2/4] handwritten warmup done
[2/4] handwritten rep 0: 11676.0 ms (5.481 t/s)
[2/4] handwritten rep 1: 11626.0 ms (5.505 t/s)
[2/4] handwritten rep 2: 12212.0 ms (5.241 t/s)

--- run 3/4: handwritten ---
[3/4] handwritten model load: 6943.0 ms
[3/4] handwritten warmup done
[3/4] handwritten rep 0: 11643.0 ms (5.497 t/s)
[3/4] handwritten rep 1: 11861.0 ms (5.396 t/s)
[3/4] handwritten rep 2: 12530.0 ms (5.108 t/s)

--- run 4/4: generic ---
[4/4] generic model load: 6811.0 ms
[4/4] generic warmup done
[4/4] generic rep 0: 14146.0 ms (4.524 t/s)
[4/4] generic rep 1: 14200.0 ms (4.507 t/s)
[4/4] generic rep 2: 14845.0 ms (4.311 t/s)

=== FINAL ===
generic median: 14376.00 ms
handwritten median: 11768.50 ms
speedup: 1.222x

{
  "schema": "p1-browser-abba-v1",
  "timestamp": "2026-09-13T19:07:08.322Z",
  "browser": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
  "hardware_concurrency": 8,
  "device_memory_gb": null,
  "cross_origin_isolated": false,
  "model": {
    "name": "ggml-model-i2_s.gguf",
    "bytes": 1844472032
  },
  "workload": {
    "kind": "prefill",
    "n_tokens": 64,
    "threads": 1,
    "warmups_per_worker": 1,
    "measurements_per_worker": 3,
    "order": [
      "generic",
      "handwritten",
      "handwritten",
      "generic"
    ]
  },
  "generic": {
    "variant": "generic",
    "sample_count": 6,
    "pooled_median_ms": 14376,
    "pooled_median_tokens_per_second": 4.451934205935,
    "mean_ms": 14405.833333333334,
    "stddev_ms": 252.36910798801557,
    "cv": 0.017518535870053722,
    "run_medians_ms": [
      14433,
      14200
    ],
    "samples_ms": [
      14433,
      14319,
      14492,
      14146,
      14200,
      14845
    ]
  },
  "handwritten": {
    "variant": "handwritten",
    "sample_count": 6,
    "pooled_median_ms": 11768.5,
    "pooled_median_tokens_per_second": 5.438582156065,
    "mean_ms": 11924.666666666666,
    "stddev_ms": 369.7067306212678,
    "cv": 0.031003527474249552,
    "run_medians_ms": [
      11676,
      11861
    ],
    "samples_ms": [
      11676,
      11626,
      12212,
      11643,
      11861,
      12530
    ]
  },
  "speedup": 1.2215660449505035,
  "suite_wall_ms": 238244,
  "notes": [
    "Fresh Web Worker for every ABBA position.",
    "Model load excluded from workload timing.",
    "No measurement samples removed as outliers.",
    "Pooled median uses all six samples per implementation."
  ]
}

================================
ABBA prefill-128
model: ggml-model-i2_s.gguf
bytes: 1844472032
order: generic -> handwritten -> handwritten -> generic

--- run 1/4: generic ---
[1/4] generic model load: 5517.0 ms
[1/4] generic warmup done
[1/4] generic rep 0: 29061.0 ms (4.405 t/s)
[1/4] generic rep 1: 28414.0 ms (4.505 t/s)
[1/4] generic rep 2: 29412.0 ms (4.352 t/s)

--- run 2/4: handwritten ---
[2/4] handwritten model load: 6725.0 ms
[2/4] handwritten warmup done
[2/4] handwritten rep 0: 24575.0 ms (5.209 t/s)
[2/4] handwritten rep 1: 23846.0 ms (5.368 t/s)
[2/4] handwritten rep 2: 25021.0 ms (5.116 t/s)

--- run 3/4: handwritten ---
[3/4] handwritten model load: 6778.0 ms
[3/4] handwritten warmup done
[3/4] handwritten rep 0: 24526.0 ms (5.219 t/s)
[3/4] handwritten rep 1: 25114.0 ms (5.097 t/s)
[3/4] handwritten rep 2: 24010.0 ms (5.331 t/s)

--- run 4/4: generic ---
[4/4] generic model load: 6827.0 ms
[4/4] generic warmup done
[4/4] generic rep 0: 28061.0 ms (4.561 t/s)
[4/4] generic rep 1: 28802.0 ms (4.444 t/s)
[4/4] generic rep 2: 29000.0 ms (4.414 t/s)

=== FINAL ===
generic median: 28901.00 ms
handwritten median: 24550.50 ms
speedup: 1.177x

{
  "schema": "p1-browser-abba-v1",
  "timestamp": "2026-09-13T19:14:52.893Z",
  "browser": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
  "hardware_concurrency": 8,
  "device_memory_gb": null,
  "cross_origin_isolated": false,
  "model": {
    "name": "ggml-model-i2_s.gguf",
    "bytes": 1844472032
  },
  "workload": {
    "kind": "prefill",
    "n_tokens": 128,
    "threads": 1,
    "warmups_per_worker": 1,
    "measurements_per_worker": 3,
    "order": [
      "generic",
      "handwritten",
      "handwritten",
      "generic"
    ]
  },
  "generic": {
    "variant": "generic",
    "sample_count": 6,
    "pooled_median_ms": 28901,
    "pooled_median_tokens_per_second": 4.428964463674999,
    "mean_ms": 28791.666666666668,
    "stddev_ms": 485.2564957490694,
    "cv": 0.016854060633831644,
    "run_medians_ms": [
      29061,
      28802
    ],
    "samples_ms": [
      29061,
      28414,
      29412,
      28061,
      28802,
      29000
    ]
  },
  "handwritten": {
    "variant": "handwritten",
    "sample_count": 6,
    "pooled_median_ms": 24550.5,
    "pooled_median_tokens_per_second": 5.213748293275,
    "mean_ms": 24515.333333333332,
    "stddev_ms": 514.0317759308919,
    "cv": 0.020967766129941473,
    "run_medians_ms": [
      24575,
      24526
    ],
    "samples_ms": [
      24575,
      23846,
      25021,
      24526,
      25114,
      24010
    ]
  },
  "speedup": 1.1772061668805116,
  "suite_wall_ms": 456141,
  "notes": [
    "Fresh Web Worker for every ABBA position.",
    "Model load excluded from workload timing.",
    "No measurement samples removed as outliers.",
    "Pooled median uses all six samples per implementation."
  ]
}

================================
ABBA prefill-32
model: ggml-model-i2_s.gguf
bytes: 1844472032
order: generic -> handwritten -> handwritten -> generic

--- run 1/4: generic ---
[1/4] generic model load: 4785.0 ms
[1/4] generic warmup done
[1/4] generic rep 0: 6821.0 ms (4.691 t/s)
[1/4] generic rep 1: 7175.0 ms (4.460 t/s)
[1/4] generic rep 2: 7203.0 ms (4.443 t/s)

--- run 2/4: handwritten ---
[2/4] handwritten model load: 6906.0 ms
[2/4] handwritten warmup done
[2/4] handwritten rep 0: 5823.0 ms (5.495 t/s)
[2/4] handwritten rep 1: 6431.0 ms (4.976 t/s)
[2/4] handwritten rep 2: 5772.0 ms (5.544 t/s)

--- run 3/4: handwritten ---
[3/4] handwritten model load: 6700.0 ms
[3/4] handwritten warmup done
[3/4] handwritten rep 0: 5821.0 ms (5.497 t/s)
[3/4] handwritten rep 1: 5818.0 ms (5.500 t/s)
[3/4] handwritten rep 2: 5859.0 ms (5.462 t/s)

--- run 4/4: generic ---
[4/4] generic model load: 6765.0 ms
[4/4] generic warmup done
[4/4] generic rep 0: 7664.0 ms (4.175 t/s)
[4/4] generic rep 1: 7010.0 ms (4.565 t/s)
[4/4] generic rep 2: 6988.0 ms (4.579 t/s)

=== FINAL ===
generic median: 7092.50 ms
handwritten median: 5822.00 ms
speedup: 1.218x

{
  "schema": "p1-browser-abba-v1",
  "timestamp": "2026-09-13T19:18:16.308Z",
  "browser": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
  "hardware_concurrency": 8,
  "device_memory_gb": null,
  "cross_origin_isolated": false,
  "model": {
    "name": "ggml-model-i2_s.gguf",
    "bytes": 1844472032
  },
  "workload": {
    "kind": "prefill",
    "n_tokens": 32,
    "threads": 1,
    "warmups_per_worker": 1,
    "measurements_per_worker": 3,
    "order": [
      "generic",
      "handwritten",
      "handwritten",
      "generic"
    ]
  },
  "generic": {
    "variant": "generic",
    "sample_count": 6,
    "pooled_median_ms": 7092.5,
    "pooled_median_tokens_per_second": 4.512418794455,
    "mean_ms": 7143.5,
    "stddev_ms": 290.3313624119861,
    "cv": 0.0406427328917178,
    "run_medians_ms": [
      7175,
      7010
    ],
    "samples_ms": [
      6821,
      7175,
      7203,
      7664,
      7010,
      6988
    ]
  },
  "handwritten": {
    "variant": "handwritten",
    "sample_count": 6,
    "pooled_median_ms": 5822,
    "pooled_median_tokens_per_second": 5.496393154255,
    "mean_ms": 5920.666666666667,
    "stddev_ms": 251.53820120742427,
    "cv": 0.04248477669306794,
    "run_medians_ms": [
      5823,
      5821
    ],
    "samples_ms": [
      5823,
      6431,
      5772,
      5821,
      5818,
      5859
    ]
  },
  "speedup": 1.218223978014428,
  "suite_wall_ms": 128620,
  "notes": [
    "Fresh Web Worker for every ABBA position.",
    "Model load excluded from workload timing.",
    "No measurement samples removed as outliers.",
    "Pooled median uses all six samples per implementation."
  ]
}

================================
ABBA prefill-256
model: ggml-model-i2_s.gguf
bytes: 1844472032
order: generic -> handwritten -> handwritten -> generic

--- run 1/4: generic ---
[1/4] generic model load: 4680.0 ms
[1/4] generic warmup done
[1/4] generic rep 0: 60052.0 ms (4.263 t/s)
[1/4] generic rep 1: 59292.0 ms (4.318 t/s)
[1/4] generic rep 2: 59606.0 ms (4.295 t/s)

--- run 2/4: handwritten ---
[2/4] handwritten model load: 6879.0 ms
[2/4] handwritten warmup done
[2/4] handwritten rep 0: 51668.0 ms (4.955 t/s)
[2/4] handwritten rep 1: 51732.0 ms (4.949 t/s)
[2/4] handwritten rep 2: 52146.0 ms (4.909 t/s)

--- run 3/4: handwritten ---
[3/4] handwritten model load: 6919.0 ms
[3/4] handwritten warmup done
[3/4] handwritten rep 0: 52061.0 ms (4.917 t/s)
[3/4] handwritten rep 1: 51530.0 ms (4.968 t/s)
[3/4] handwritten rep 2: 51522.0 ms (4.969 t/s)

--- run 4/4: generic ---
[4/4] generic model load: 6844.0 ms
[4/4] generic warmup done
[4/4] generic rep 0: 58951.0 ms (4.343 t/s)
[4/4] generic rep 1: 60270.0 ms (4.248 t/s)
[4/4] generic rep 2: 60390.0 ms (4.239 t/s)

=== FINAL ===
generic median: 59829.00 ms
handwritten median: 51700.00 ms
speedup: 1.157x

{
  "schema": "p1-browser-abba-v1",
  "timestamp": "2026-09-13T19:34:26.555Z",
  "browser": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
  "hardware_concurrency": 8,
  "device_memory_gb": null,
  "cross_origin_isolated": false,
  "model": {
    "name": "ggml-model-i2_s.gguf",
    "bytes": 1844472032
  },
  "workload": {
    "kind": "prefill",
    "n_tokens": 256,
    "threads": 1,
    "warmups_per_worker": 1,
    "measurements_per_worker": 3,
    "order": [
      "generic",
      "handwritten",
      "handwritten",
      "generic"
    ]
  },
  "generic": {
    "variant": "generic",
    "sample_count": 6,
    "pooled_median_ms": 59829,
    "pooled_median_tokens_per_second": 4.2789208674250006,
    "mean_ms": 59760.166666666664,
    "stddev_ms": 572.6228834640358,
    "cv": 0.009582016172378522,
    "run_medians_ms": [
      59606,
      60270
    ],
    "samples_ms": [
      60052,
      59292,
      59606,
      58951,
      60270,
      60390
    ]
  },
  "handwritten": {
    "variant": "handwritten",
    "sample_count": 6,
    "pooled_median_ms": 51700,
    "pooled_median_tokens_per_second": 4.9516459975850005,
    "mean_ms": 51776.5,
    "stddev_ms": 267.11626682027435,
    "cv": 0.0051590251720428065,
    "run_medians_ms": [
      51732,
      51530
    ],
    "samples_ms": [
      51668,
      51732,
      52146,
      52061,
      51530,
      51522
    ]
  },
  "speedup": 1.1572340425531915,
  "suite_wall_ms": 920404,
  "notes": [
    "Fresh Web Worker for every ABBA position.",
    "Model load excluded from workload timing.",
    "No measurement samples removed as outliers.",
    "Pooled median uses all six samples per implementation."
  ]
}

================================
ABBA decode-64
model: ggml-model-i2_s.gguf
bytes: 1844472032
order: generic -> handwritten -> handwritten -> generic

--- run 1/4: generic ---
[1/4] generic model load: 5466.0 ms
[1/4] generic warmup done
[1/4] generic rep 0: 32104.0 ms (1.994 t/s)
[1/4] generic rep 1: 32661.0 ms (1.960 t/s)
[1/4] generic rep 2: 32200.0 ms (1.988 t/s)

--- run 2/4: handwritten ---
[2/4] handwritten model load: 6812.0 ms
[2/4] handwritten warmup done
[2/4] handwritten rep 0: 29869.0 ms (2.143 t/s)
[2/4] handwritten rep 1: 30707.0 ms (2.084 t/s)
[2/4] handwritten rep 2: 31134.0 ms (2.056 t/s)

--- run 3/4: handwritten ---
[3/4] handwritten model load: 7259.0 ms
[3/4] handwritten warmup done
[3/4] handwritten rep 0: 30820.0 ms (2.077 t/s)
[3/4] handwritten rep 1: 29759.0 ms (2.151 t/s)
[3/4] handwritten rep 2: 30600.0 ms (2.092 t/s)

--- run 4/4: generic ---
[4/4] generic model load: 6781.0 ms
[4/4] generic warmup done
[4/4] generic rep 0: 33809.0 ms (1.893 t/s)
[4/4] generic rep 1: 32703.0 ms (1.957 t/s)
[4/4] generic rep 2: 32022.0 ms (1.999 t/s)

=== FINAL ===
generic median: 32430.50 ms
handwritten median: 30653.50 ms
speedup: 1.058x

{
  "schema": "p1-browser-abba-v1",
  "timestamp": "2026-09-13T19:45:38.425Z",
  "browser": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
  "hardware_concurrency": 8,
  "device_memory_gb": null,
  "cross_origin_isolated": false,
  "model": {
    "name": "ggml-model-i2_s.gguf",
    "bytes": 1844472032
  },
  "workload": {
    "kind": "decode",
    "n_tokens": 64,
    "threads": 1,
    "warmups_per_worker": 1,
    "measurements_per_worker": 3,
    "order": [
      "generic",
      "handwritten",
      "handwritten",
      "generic"
    ]
  },
  "generic": {
    "variant": "generic",
    "sample_count": 6,
    "pooled_median_ms": 32430.5,
    "pooled_median_tokens_per_second": 1.97355061529,
    "mean_ms": 32583.166666666668,
    "stddev_ms": 665.4939268443152,
    "cv": 0.020424470514252713,
    "run_medians_ms": [
      32200,
      32703
    ],
    "samples_ms": [
      32104,
      32661,
      32200,
      33809,
      32703,
      32022
    ]
  },
  "handwritten": {
    "variant": "handwritten",
    "sample_count": 6,
    "pooled_median_ms": 30653.5,
    "pooled_median_tokens_per_second": 2.087859296735,
    "mean_ms": 30481.5,
    "stddev_ms": 548.1593746347863,
    "cv": 0.017983346444065625,
    "run_medians_ms": [
      30707,
      30600
    ],
    "samples_ms": [
      29869,
      30707,
      31134,
      30820,
      29759,
      30600
    ]
  },
  "speedup": 1.057970541699969,
  "suite_wall_ms": 554681,
  "notes": [
    "Fresh Web Worker for every ABBA position.",
    "Model load excluded from workload timing.",
    "No measurement samples removed as outliers.",
    "Pooled median uses all six samples per implementation."
  ]
}
```