# P1 Browser Evidence Through Phase 4

This bundle preserves the browser evidence accumulated so far.

## Included

- `phase3-edge-controlled/`
  - Controlled Edge inference benchmark evidence from Phase 3.
- `phase4-firefox-controlled/`
  - Firefox 150 controlled ABBA inference runs.
  - `prefill-32` was measured twice; both independent suites are preserved.
- `phase4-kernel-isolation/`
  - Edge and Firefox browser microkernel ABBA results.
  - Cross-engine summary.

## Important interpretation

The same WASM artifacts behave very differently across engines.

Controlled inference:
- Edge: handwritten SIMD128 gains are large (about 1.80-1.99x for prefill, 1.34x decode).
- Firefox: gains are much smaller (about 1.16-1.22x for the stable larger prefill workloads, about 1.06x decode).

The microkernel isolation points in the same direction:
- Firefox geomean microkernel speedup: ~1.20x.
- Edge reported ~3.18x in this ABBA run, but the generic Edge workers varied strongly, so that exact number is NOT frozen as final.

No outliers were removed from the controlled inference runs.
