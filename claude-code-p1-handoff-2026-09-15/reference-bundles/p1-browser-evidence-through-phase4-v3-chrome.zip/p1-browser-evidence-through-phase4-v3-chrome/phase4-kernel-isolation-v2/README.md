# Phase 4B v2 — Cross-engine microkernel stability

Exact same WASM artifacts were measured in Edge 152 and Firefox 150.

## Firefox

- pooled geomean speedup: **1.199x**
- cycle geomeans: 1.190x, 1.212x, 1.203x
- geometric mean of cycle geomeans: **1.201x**
- stable low worker-to-worker variation.

## Edge

- pooled per-size median geomean: **1.578x**
- cycle geomeans: 1.958x, 1.851x, 2.204x
- geometric mean of cycle geomeans: **1.999x**
- worker-to-worker variation is very high, so the pooled 1.578x value is NOT frozen as the final Edge microkernel speedup.
- paired cycle-level results remain close to ~2x, but the exact Edge kernel number is still provisional.

## Interpretation

The engine effect is real enough to justify further investigation: Firefox keeps generic/autovec much closer to handwritten SIMD, while Edge shows a much larger advantage for handwritten SIMD. The next benchmark should reduce Edge worker-state/JIT variability by extending warm-up inside each measured worker rather than priming separate workers.
