```
=== PRIMING — NOT MEASURED ===
[prime 1/4] generic n=2560 0.000350475 ms
[prime 1/4] generic n=3200 0.000437355 ms
[prime 1/4] generic n=6912 0.001312637 ms
[prime 1/4] generic n=8192 0.001548004 ms
[prime 2/4] handwritten n=2560 0.000235939 ms
[prime 2/4] handwritten n=3200 0.000290489 ms
[prime 2/4] handwritten n=6912 0.000622368 ms
[prime 2/4] handwritten n=8192 0.000739479 ms
[prime 3/4] generic n=2560 0.000464439 ms
[prime 3/4] generic n=3200 0.000554657 ms
[prime 3/4] generic n=6912 0.001161194 ms
[prime 3/4] generic n=8192 0.001663971 ms
[prime 4/4] handwritten n=2560 0.000221395 ms
[prime 4/4] handwritten n=3200 0.000273037 ms
[prime 4/4] handwritten n=6912 0.000592041 ms
[prime 4/4] handwritten n=8192 0.000686455 ms

=== MEASURED: 3 × ABBA ===

--- cycle 1 position 1/4 generic ---
[C1 P1] generic n=2560 0.000455952 ms
[C1 P1] generic n=3200 0.000582886 ms
[C1 P1] generic n=6912 0.001177979 ms
[C1 P1] generic n=8192 0.001388931 ms

--- cycle 1 position 2/4 handwritten ---
[C1 P2] handwritten n=2560 0.000238895 ms
[C1 P2] handwritten n=3200 0.000270271 ms
[C1 P2] handwritten n=6912 0.000590134 ms
[C1 P2] handwritten n=8192 0.000698662 ms

--- cycle 1 position 3/4 handwritten ---
[C1 P3] handwritten n=2560 0.000227070 ms
[C1 P3] handwritten n=3200 0.000285435 ms
[C1 P3] handwritten n=6912 0.000711632 ms
[C1 P3] handwritten n=8192 0.000694466 ms

--- cycle 1 position 4/4 generic ---
[C1 P4] generic n=2560 0.000438213 ms
[C1 P4] generic n=3200 0.000583076 ms
[C1 P4] generic n=6912 0.001197815 ms
[C1 P4] generic n=8192 0.001396561 ms

--- cycle 2 position 1/4 generic ---
[C2 P1] generic n=2560 0.000473404 ms
[C2 P1] generic n=3200 0.000552368 ms
[C2 P1] generic n=6912 0.001202774 ms
[C2 P1] generic n=8192 0.001528931 ms

--- cycle 2 position 2/4 handwritten ---
[C2 P2] handwritten n=2560 0.000224972 ms
[C2 P2] handwritten n=3200 0.000297642 ms
[C2 P2] handwritten n=6912 0.001548195 ms
[C2 P2] handwritten n=8192 0.001898193 ms

--- cycle 2 position 3/4 handwritten ---
[C2 P3] handwritten n=2560 0.000626183 ms
[C2 P3] handwritten n=3200 0.000740814 ms
[C2 P3] handwritten n=6912 0.001351166 ms
[C2 P3] handwritten n=8192 0.000590515 ms

--- cycle 2 position 4/4 generic ---
[C2 P4] generic n=2560 0.001219940 ms
[C2 P4] generic n=3200 0.001471710 ms
[C2 P4] generic n=6912 0.003144836 ms
[C2 P4] generic n=8192 0.003497314 ms

--- cycle 3 position 1/4 generic ---
[C3 P1] generic n=2560 0.001086426 ms
[C3 P1] generic n=3200 0.001451111 ms
[C3 P1] generic n=6912 0.003059387 ms
[C3 P1] generic n=8192 0.003707123 ms

--- cycle 3 position 2/4 handwritten ---
[C3 P2] handwritten n=2560 0.000617599 ms
[C3 P2] handwritten n=3200 0.000760841 ms
[C3 P2] handwritten n=6912 0.001534271 ms
[C3 P2] handwritten n=8192 0.000628853 ms

--- cycle 3 position 3/4 handwritten ---
[C3 P3] handwritten n=2560 0.000613594 ms
[C3 P3] handwritten n=3200 0.000619316 ms
[C3 P3] handwritten n=6912 0.000481224 ms
[C3 P3] handwritten n=8192 0.000552177 ms

--- cycle 3 position 4/4 generic ---
[C3 P4] generic n=2560 0.000477886 ms
[C3 P4] generic n=3200 0.000564003 ms
[C3 P4] generic n=6912 0.001179504 ms
[C3 P4] generic n=8192 0.003435135 ms

=== FINAL STABILITY RESULT ===
n=2560 speedup=1.116x G-CV=52.03% H-CV=50.16%
  cycle 1: 1.919x
  cycle 2: 1.989x
  cycle 3: 1.271x
n=3200 speedup=1.272x G-CV=53.05% H-CV=47.73%
  cycle 1: 2.098x
  cycle 2: 1.949x
  cycle 3: 1.460x
n=6912 speedup=1.164x G-CV=54.08% H-CV=47.71%
  cycle 1: 1.825x
  cycle 2: 1.500x
  cycle 3: 2.103x
n=8192 speedup=3.751x G-CV=46.52% H-CV=61.59%
  cycle 1: 1.999x
  cycle 2: 2.020x
  cycle 3: 6.047x

cycle 1 geomean: 1.958x
cycle 2 geomean: 1.851x
cycle 3 geomean: 2.204x
overall geomean: 1.578x

{
  "schema": "p1-browser-microkernel-stability-v2",
  "timestamp": "2026-09-13T20:05:42.872Z",
  "browser": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0",
  "hardware_concurrency": 8,
  "device_memory_gb": 32,
  "cross_origin_isolated": false,
  "implementation": {
    "generic": "Clang/Emscripten autovectorized WASM SIMD128",
    "handwritten": "Explicit WASM SIMD128 using i32x4.dot_i16x8_s"
  },
  "protocol": {
    "priming_order": [
      "generic",
      "handwritten",
      "generic",
      "handwritten"
    ],
    "priming_workers": 4,
    "priming_included_in_results": false,
    "measured_cycles": 3,
    "order_per_cycle": [
      "generic",
      "handwritten",
      "handwritten",
      "generic"
    ],
    "total_measured_workers": 12,
    "measured_workers_per_implementation": 6,
    "fresh_worker_per_position": true,
    "outliers_removed": false
  },
  "rows": [
    {
      "n": 2560,
      "generic_samples_ms": [
        0.000455952,
        0.000438213,
        0.000473404,
        0.00121994,
        0.001086426,
        0.000477886
      ],
      "handwritten_samples_ms": [
        0.000238895,
        0.00022707,
        0.000224972,
        0.000626183,
        0.000617599,
        0.000613594
      ],
      "generic_median_ms": 0.000475645,
      "handwritten_median_ms": 0.0004262445,
      "generic_mean_ms": 0.0006919701666666667,
      "handwritten_mean_ms": 0.0004247188333333333,
      "generic_stddev_ms": 0.00036001333964752843,
      "handwritten_stddev_ms": 0.00021305339870879007,
      "generic_cv": 0.5202729206979709,
      "handwritten_cv": 0.5016339799124914,
      "generic_min_ms": 0.000438213,
      "generic_max_ms": 0.00121994,
      "handwritten_min_ms": 0.000224972,
      "handwritten_max_ms": 0.000626183,
      "speedup": 1.1158970966194286,
      "cycles": [
        {
          "cycle": 1,
          "generic_median_ms": 0.00044708249999999997,
          "handwritten_median_ms": 0.00023298250000000002,
          "speedup": 1.9189531402573152
        },
        {
          "cycle": 2,
          "generic_median_ms": 0.000846672,
          "handwritten_median_ms": 0.00042557749999999996,
          "speedup": 1.9894660784463467
        },
        {
          "cycle": 3,
          "generic_median_ms": 0.000782156,
          "handwritten_median_ms": 0.0006155965,
          "speedup": 1.2705660282344036
        }
      ]
    },
    {
      "n": 3200,
      "generic_samples_ms": [
        0.000582886,
        0.000583076,
        0.000552368,
        0.00147171,
        0.001451111,
        0.000564003
      ],
      "handwritten_samples_ms": [
        0.000270271,
        0.000285435,
        0.000297642,
        0.000740814,
        0.000760841,
        0.000619316
      ],
      "generic_median_ms": 0.000582981,
      "handwritten_median_ms": 0.00045847899999999997,
      "generic_mean_ms": 0.0008675256666666667,
      "handwritten_mean_ms": 0.0004957198333333334,
      "generic_stddev_ms": 0.0004602156595930506,
      "handwritten_stddev_ms": 0.00023660858462990443,
      "generic_cv": 0.5304922693081326,
      "handwritten_cv": 0.4773030424037995,
      "generic_min_ms": 0.000552368,
      "generic_max_ms": 0.00147171,
      "handwritten_min_ms": 0.000270271,
      "handwritten_max_ms": 0.000760841,
      "speedup": 1.2715544223399546,
      "cycles": [
        {
          "cycle": 1,
          "generic_median_ms": 0.000582981,
          "handwritten_median_ms": 0.000277853,
          "speedup": 2.0981634173465826
        },
        {
          "cycle": 2,
          "generic_median_ms": 0.001012039,
          "handwritten_median_ms": 0.000519228,
          "speedup": 1.9491225434683797
        },
        {
          "cycle": 3,
          "generic_median_ms": 0.001007557,
          "handwritten_median_ms": 0.0006900785,
          "speedup": 1.4600614277940844
        }
      ]
    },
    {
      "n": 6912,
      "generic_samples_ms": [
        0.001177979,
        0.001197815,
        0.001202774,
        0.003144836,
        0.003059387,
        0.001179504
      ],
      "handwritten_samples_ms": [
        0.000590134,
        0.000711632,
        0.001548195,
        0.001351166,
        0.001534271,
        0.000481224
      ],
      "generic_median_ms": 0.0012002945,
      "handwritten_median_ms": 0.0010313990000000001,
      "generic_mean_ms": 0.0018270491666666664,
      "handwritten_mean_ms": 0.0010361036666666666,
      "generic_stddev_ms": 0.0009880769826201632,
      "handwritten_stddev_ms": 0.00049431462654818,
      "generic_cv": 0.540804812835358,
      "handwritten_cv": 0.47708993071946154,
      "generic_min_ms": 0.001177979,
      "generic_max_ms": 0.003144836,
      "handwritten_min_ms": 0.000481224,
      "handwritten_max_ms": 0.001548195,
      "speedup": 1.1637537946032523,
      "cycles": [
        {
          "cycle": 1,
          "generic_median_ms": 0.001187897,
          "handwritten_median_ms": 0.000650883,
          "speedup": 1.8250545797017284
        },
        {
          "cycle": 2,
          "generic_median_ms": 0.002173805,
          "handwritten_median_ms": 0.0014496805,
          "speedup": 1.4995062705196076
        },
        {
          "cycle": 3,
          "generic_median_ms": 0.0021194455,
          "handwritten_median_ms": 0.0010077475,
          "speedup": 2.103151335031841
        }
      ]
    },
    {
      "n": 8192,
      "generic_samples_ms": [
        0.001388931,
        0.001396561,
        0.001528931,
        0.003497314,
        0.003707123,
        0.003435135
      ],
      "handwritten_samples_ms": [
        0.000698662,
        0.000694466,
        0.001898193,
        0.000590515,
        0.000628853,
        0.000552177
      ],
      "generic_median_ms": 0.0024820330000000002,
      "handwritten_median_ms": 0.0006616594999999999,
      "generic_mean_ms": 0.0024923325,
      "handwritten_mean_ms": 0.000843811,
      "generic_stddev_ms": 0.0011593906010362084,
      "handwritten_stddev_ms": 0.0005197133360778805,
      "generic_cv": 0.46518295654219827,
      "handwritten_cv": 0.6159120183049054,
      "generic_min_ms": 0.001388931,
      "generic_max_ms": 0.003707123,
      "handwritten_min_ms": 0.000552177,
      "handwritten_max_ms": 0.001898193,
      "speedup": 3.751224005700818,
      "cycles": [
        {
          "cycle": 1,
          "generic_median_ms": 0.0013927459999999998,
          "handwritten_median_ms": 0.000696564,
          "speedup": 1.9994515938233957
        },
        {
          "cycle": 2,
          "generic_median_ms": 0.0025131225,
          "handwritten_median_ms": 0.001244354,
          "speedup": 2.0196202206124623
        },
        {
          "cycle": 3,
          "generic_median_ms": 0.003571129,
          "handwritten_median_ms": 0.000590515,
          "speedup": 6.047482282414503
        }
      ]
    }
  ],
  "geometric_mean_speedup": 1.5776051027859679,
  "cycle_geometric_mean_speedups": [
    {
      "cycle": 1,
      "geometric_mean_speedup": 1.9578193111317643
    },
    {
      "cycle": 2,
      "geometric_mean_speedup": 1.851179021068193
    },
    {
      "cycle": 3,
      "geometric_mean_speedup": 2.2039583037986565
    }
  ],
  "suite_wall_ms": 204650.80000001192
}
```