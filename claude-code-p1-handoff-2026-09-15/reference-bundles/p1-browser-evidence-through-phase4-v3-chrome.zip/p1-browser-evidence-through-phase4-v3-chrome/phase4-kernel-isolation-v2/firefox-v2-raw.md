```
=== PRIMING — NOT MEASURED ===
[prime 1/4] generic n=2560 0.000218391 ms
[prime 1/4] generic n=3200 0.000263214 ms
[prime 1/4] generic n=6912 0.000581741 ms
[prime 1/4] generic n=8192 0.000825882 ms
[prime 2/4] handwritten n=2560 0.000226021 ms
[prime 2/4] handwritten n=3200 0.000271797 ms
[prime 2/4] handwritten n=6912 0.000570297 ms
[prime 2/4] handwritten n=8192 0.000669479 ms
[prime 3/4] generic n=2560 0.000261307 ms
[prime 3/4] generic n=3200 0.000342369 ms
[prime 3/4] generic n=6912 0.000694275 ms
[prime 3/4] generic n=8192 0.000808716 ms
[prime 4/4] handwritten n=2560 0.000228882 ms
[prime 4/4] handwritten n=3200 0.000268936 ms
[prime 4/4] handwritten n=6912 0.000568390 ms
[prime 4/4] handwritten n=8192 0.000806808 ms

=== MEASURED: 3 × ABBA ===

--- cycle 1 position 1/4 generic ---
[C1 P1] generic n=2560 0.000270844 ms
[C1 P1] generic n=3200 0.000316620 ms
[C1 P1] generic n=6912 0.000787735 ms
[C1 P1] generic n=8192 0.000871658 ms

--- cycle 1 position 2/4 handwritten ---
[C1 P2] handwritten n=2560 0.000213623 ms
[C1 P2] handwritten n=3200 0.000286102 ms
[C1 P2] handwritten n=6912 0.000602722 ms
[C1 P2] handwritten n=8192 0.000717163 ms

--- cycle 1 position 3/4 handwritten ---
[C1 P3] handwritten n=2560 0.000272751 ms
[C1 P3] handwritten n=3200 0.000275612 ms
[C1 P3] handwritten n=6912 0.000597000 ms
[C1 P3] handwritten n=8192 0.000705719 ms

--- cycle 1 position 4/4 generic ---
[C1 P4] generic n=2560 0.000299454 ms
[C1 P4] generic n=3200 0.000340462 ms
[C1 P4] generic n=6912 0.000684738 ms
[C1 P4] generic n=8192 0.000823975 ms

--- cycle 2 position 1/4 generic ---
[C2 P1] generic n=2560 0.000261307 ms
[C2 P1] generic n=3200 0.000322342 ms
[C2 P1] generic n=6912 0.000724792 ms
[C2 P1] generic n=8192 0.000823975 ms

--- cycle 2 position 2/4 handwritten ---
[C2 P2] handwritten n=2560 0.000215530 ms
[C2 P2] handwritten n=3200 0.000262260 ms
[C2 P2] handwritten n=6912 0.000562668 ms
[C2 P2] handwritten n=8192 0.000673294 ms

--- cycle 2 position 3/4 handwritten ---
[C2 P3] handwritten n=2560 0.000227451 ms
[C2 P3] handwritten n=3200 0.000265121 ms
[C2 P3] handwritten n=6912 0.000555038 ms
[C2 P3] handwritten n=8192 0.000671387 ms

--- cycle 2 position 4/4 generic ---
[C2 P4] generic n=2560 0.000259399 ms
[C2 P4] generic n=3200 0.000317574 ms
[C2 P4] generic n=6912 0.000675201 ms
[C2 P4] generic n=8192 0.000799179 ms

--- cycle 3 position 1/4 generic ---
[C3 P1] generic n=2560 0.000259399 ms
[C3 P1] generic n=3200 0.000321388 ms
[C3 P1] generic n=6912 0.000677109 ms
[C3 P1] generic n=8192 0.000814438 ms

--- cycle 3 position 2/4 handwritten ---
[C3 P2] handwritten n=2560 0.000211239 ms
[C3 P2] handwritten n=3200 0.000262260 ms
[C3 P2] handwritten n=6912 0.000581741 ms
[C3 P2] handwritten n=8192 0.000701904 ms

--- cycle 3 position 3/4 handwritten ---
[C3 P3] handwritten n=2560 0.000215530 ms
[C3 P3] handwritten n=3200 0.000269890 ms
[C3 P3] handwritten n=6912 0.000556946 ms
[C3 P3] handwritten n=8192 0.000656128 ms

--- cycle 3 position 4/4 generic ---
[C3 P4] generic n=2560 0.000255585 ms
[C3 P4] generic n=3200 0.000323296 ms
[C3 P4] generic n=6912 0.000680923 ms
[C3 P4] generic n=8192 0.000814438 ms

=== FINAL STABILITY RESULT ===
n=2560 speedup=1.208x G-CV=6.12% H-CV=10.43%
  cycle 1: 1.173x
  cycle 2: 1.175x
  cycle 3: 1.207x
n=3200 speedup=1.203x G-CV=2.68% H-CV=3.45%
  cycle 1: 1.170x
  cycle 2: 1.213x
  cycle 3: 1.211x
n=6912 speedup=1.193x G-CV=6.31% H-CV=3.62%
  cycle 1: 1.227x
  cycle 2: 1.253x
  cycle 3: 1.193x
n=8192 speedup=1.191x G-CV=3.00% H-CV=3.48%
  cycle 1: 1.192x
  cycle 2: 1.207x
  cycle 3: 1.199x

cycle 1 geomean: 1.190x
cycle 2 geomean: 1.212x
cycle 3 geomean: 1.203x
overall geomean: 1.199x

{
  "schema": "p1-browser-microkernel-stability-v2",
  "timestamp": "2026-09-13T20:10:28.658Z",
  "browser": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
  "hardware_concurrency": 8,
  "device_memory_gb": null,
  "cross_origin_isolated": false,
  "implementation": {
    "generic": "Clang/Emscripten autovectorized WASM SIMD128",
    "handwritten": "Explicit WASM SIMD128 using i32x4.dot_i16x8_s"
  },
  "protocol": {
    "priming_order": [
      "generic",
      "handwritten",
      "generic",
      "handwritten"
    ],
    "priming_workers": 4,
    "priming_included_in_results": false,
    "measured_cycles": 3,
    "order_per_cycle": [
      "generic",
      "handwritten",
      "handwritten",
      "generic"
    ],
    "total_measured_workers": 12,
    "measured_workers_per_implementation": 6,
    "fresh_worker_per_position": true,
    "outliers_removed": false
  },
  "rows": [
    {
      "n": 2560,
      "generic_samples_ms": [
        0.000270844,
        0.000299454,
        0.000261307,
        0.000259399,
        0.000259399,
        0.000255585
      ],
      "handwritten_samples_ms": [
        0.000213623,
        0.000272751,
        0.00021553,
        0.000227451,
        0.000211239,
        0.00021553
      ],
      "generic_median_ms": 0.000260353,
      "handwritten_median_ms": 0.00021553,
      "generic_mean_ms": 0.00026766466666666667,
      "handwritten_mean_ms": 0.00022602066666666668,
      "generic_stddev_ms": 0.000016392990192965608,
      "handwritten_stddev_ms": 0.000023571499270658767,
      "generic_cv": 0.06124450566118405,
      "handwritten_cv": 0.10428913257486233,
      "generic_min_ms": 0.000255585,
      "generic_max_ms": 0.000299454,
      "handwritten_min_ms": 0.000211239,
      "handwritten_max_ms": 0.000272751,
      "speedup": 1.2079664083886235,
      "cycles": [
        {
          "cycle": 1,
          "generic_median_ms": 0.000285149,
          "handwritten_median_ms": 0.00024318700000000001,
          "speedup": 1.172550341917948
        },
        {
          "cycle": 2,
          "generic_median_ms": 0.000260353,
          "handwritten_median_ms": 0.00022149049999999998,
          "speedup": 1.175458992597877
        },
        {
          "cycle": 3,
          "generic_median_ms": 0.000257492,
          "handwritten_median_ms": 0.0002133845,
          "speedup": 1.2067043295084694
        }
      ]
    },
    {
      "n": 3200,
      "generic_samples_ms": [
        0.00031662,
        0.000340462,
        0.000322342,
        0.000317574,
        0.000321388,
        0.000323296
      ],
      "handwritten_samples_ms": [
        0.000286102,
        0.000275612,
        0.00026226,
        0.000265121,
        0.00026226,
        0.00026989
      ],
      "generic_median_ms": 0.00032186499999999995,
      "handwritten_median_ms": 0.0002675055,
      "generic_mean_ms": 0.00032361366666666663,
      "handwritten_mean_ms": 0.0002702075,
      "generic_stddev_ms": 0.000008670950620702818,
      "handwritten_stddev_ms": 0.000009318181705676272,
      "generic_cv": 0.0267941422561557,
      "handwritten_cv": 0.03448528151763468,
      "generic_min_ms": 0.00031662,
      "generic_max_ms": 0.000340462,
      "handwritten_min_ms": 0.00026226,
      "handwritten_max_ms": 0.000286102,
      "speedup": 1.2032089059851105,
      "cycles": [
        {
          "cycle": 1,
          "generic_median_ms": 0.000328541,
          "handwritten_median_ms": 0.000280857,
          "speedup": 1.1697803508547053
        },
        {
          "cycle": 2,
          "generic_median_ms": 0.00031995799999999996,
          "handwritten_median_ms": 0.00026369049999999997,
          "speedup": 1.2133846308456315
        },
        {
          "cycle": 3,
          "generic_median_ms": 0.000322342,
          "handwritten_median_ms": 0.000266075,
          "speedup": 1.211470450061073
        }
      ]
    },
    {
      "n": 6912,
      "generic_samples_ms": [
        0.000787735,
        0.000684738,
        0.000724792,
        0.000675201,
        0.000677109,
        0.000680923
      ],
      "handwritten_samples_ms": [
        0.000602722,
        0.000597,
        0.000562668,
        0.000555038,
        0.000581741,
        0.000556946
      ],
      "generic_median_ms": 0.0006828305,
      "handwritten_median_ms": 0.0005722044999999999,
      "generic_mean_ms": 0.000705083,
      "handwritten_mean_ms": 0.0005760191666666667,
      "generic_stddev_ms": 0.00004448123426794722,
      "handwritten_stddev_ms": 0.00002082414341495626,
      "generic_cv": 0.06308652210866979,
      "handwritten_cv": 0.03615182379340316,
      "generic_min_ms": 0.000675201,
      "generic_max_ms": 0.000787735,
      "handwritten_min_ms": 0.000555038,
      "handwritten_max_ms": 0.000602722,
      "speedup": 1.1933329779825221,
      "cycles": [
        {
          "cycle": 1,
          "generic_median_ms": 0.0007362365,
          "handwritten_median_ms": 0.0005998609999999999,
          "speedup": 1.2273451682973224
        },
        {
          "cycle": 2,
          "generic_median_ms": 0.0006999965,
          "handwritten_median_ms": 0.000558853,
          "speedup": 1.2525592597695636
        },
        {
          "cycle": 3,
          "generic_median_ms": 0.000679016,
          "handwritten_median_ms": 0.0005693435,
          "speedup": 1.192629756904224
        }
      ]
    },
    {
      "n": 8192,
      "generic_samples_ms": [
        0.000871658,
        0.000823975,
        0.000823975,
        0.000799179,
        0.000814438,
        0.000814438
      ],
      "handwritten_samples_ms": [
        0.000717163,
        0.000705719,
        0.000673294,
        0.000671387,
        0.000701904,
        0.000656128
      ],
      "generic_median_ms": 0.0008192065,
      "handwritten_median_ms": 0.000687599,
      "generic_mean_ms": 0.0008246105,
      "handwritten_mean_ms": 0.0006875991666666667,
      "generic_stddev_ms": 0.00002477093329489221,
      "handwritten_stddev_ms": 0.000023936931009773763,
      "generic_cv": 0.03003955600236986,
      "handwritten_cv": 0.034812332780760735,
      "generic_min_ms": 0.000799179,
      "generic_max_ms": 0.000871658,
      "handwritten_min_ms": 0.000656128,
      "handwritten_max_ms": 0.000717163,
      "speedup": 1.1914015290889022,
      "cycles": [
        {
          "cycle": 1,
          "generic_median_ms": 0.0008478165,
          "handwritten_median_ms": 0.000711441,
          "speedup": 1.1916891210936675
        },
        {
          "cycle": 2,
          "generic_median_ms": 0.000811577,
          "handwritten_median_ms": 0.0006723405,
          "speedup": 1.2070922397207962
        },
        {
          "cycle": 3,
          "generic_median_ms": 0.000814438,
          "handwritten_median_ms": 0.000679016,
          "speedup": 1.1994385993849925
        }
      ]
    }
  ],
  "geometric_mean_speedup": 1.1989578699891803,
  "cycle_geometric_mean_speedups": [
    {
      "cycle": 1,
      "geometric_mean_speedup": 1.1901217109253475
    },
    {
      "cycle": 2,
      "geometric_mean_speedup": 1.2118145929918767
    },
    {
      "cycle": 3,
      "geometric_mean_speedup": 1.202539469382262
    }
  ],
  "suite_wall_ms": 182654
}
```