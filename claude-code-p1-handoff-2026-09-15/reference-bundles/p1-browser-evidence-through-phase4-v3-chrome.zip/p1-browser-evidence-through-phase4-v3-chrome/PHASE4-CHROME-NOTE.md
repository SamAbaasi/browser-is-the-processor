# Chrome v3 result

Chrome 152, exact same WASM artifacts and same-worker prewarm protocol.

- cycle 1 geomean: 1.964x
- cycle 2 geomean: 1.950x
- cycle 3 geomean: 0.643x
- pooled page geomean: 1.838x

The first two cycles are stable near ~1.95x. In cycle 3, handwritten becomes
substantially slower while generic remains comparatively stable. This reproduces
the Chromium-family instability seen in Edge and argues against an Edge-only issue.

Next recommended experiment: a dual-kernel, single-WASM, single-worker benchmark
that contains both generic/autovectorized and handwritten implementations in the
same binary, alternating them within one worker to remove cross-worker/process
state as a confounder.
